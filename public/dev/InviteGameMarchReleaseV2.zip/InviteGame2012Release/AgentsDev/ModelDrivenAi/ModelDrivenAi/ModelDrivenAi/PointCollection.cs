using System;
using System.Collections.Generic;

namespace ModelDrivenAi
{
	/**
	* The List of centroids to be used by our clustering Algorithm
	* */
	public class PointCollection : List<Point> {
		
		public Point Centroid { get; set; }
		
		public PointCollection(int dimensions, String centroid_name): base()
		{
			Centroid = new Point(dimensions, centroid_name);
		}
		
		/**
         * Adds a point to this cluster and updates its centroid.
         * */
		public void AddPoint(Point p)
		{
			this.Add(p);
			UpdateCentroid();
		}
		
		/**
         * Removes a point from this cluster and updates its centroid.
         * */
		public Point RemovePoint(int index)
		{
			Point removedPoint = new Point(this[index].getPoints(), this[index].getID());
			this.RemoveAt(index);
			UpdateCentroid();
			
			return (removedPoint);
		}
		
		/**
		 * Removes a point from this cluster and updates its centroid.
		 * */
		public Point RemovePoint(Point p)
		{
			Point removedPoint = new Point(p.getPoints(), p.getID());
			this.Remove(p);
			UpdateCentroid();
			
			return (removedPoint);
		}
		
		/**
		 * Obtains the point that is nearest to the centroid.
		 * */
		public Point GetPointNearestToCentroid()
		{
			double minimumDistance = 0.0;
			int nearestPointIndex = -1;
			
			foreach (Point p in this)
			{
				double distance = Point.FindDistance(p, Centroid);
				
				if (this.IndexOf(p) == 0)
				{
					minimumDistance = distance;
					nearestPointIndex = this.IndexOf(p);
				}
				else
				{
					if (minimumDistance > distance)
					{
						minimumDistance = distance;
						nearestPointIndex = this.IndexOf(p);
					}
				}
			}
			
			return (this[nearestPointIndex]);
		}
		
		/**
		 * Updates the Centroid of the cluster, using the mean of each point in it's cluster.
		 * */
		public void UpdateCentroid ()
		{
			double[] coordinate_sum = new double[Centroid.getPoints ().Length];
			
			for (int i = 0; i < coordinate_sum.Length; i++) 
			{
				coordinate_sum [i] = 0;
				foreach (Point p in this) {
					coordinate_sum [i] += p.getPoints () [i];
				}
				Centroid.getPoints()[i] = (coordinate_sum [i] / (double)this.Count);
			}
		}
		
		/**
		 * Prints the cluster in a String Format.
		 * */
		public override string ToString ()
		{
			string str = "Centroid :";
			foreach (double num in Centroid.getPoints()) {
				str += " " + num;
			}
			str += ". \r\nPoints List:\r\n";
			foreach (Point p in this) {
				str += p.getID () + ":";
				foreach (double num in p.getPoints()) {
					str += " " + num;
				}
				str += "\r\n";
			}
			return str;
		}
	}
}

