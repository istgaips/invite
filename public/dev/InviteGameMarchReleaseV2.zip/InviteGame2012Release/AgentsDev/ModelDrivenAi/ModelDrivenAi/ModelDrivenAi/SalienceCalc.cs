using System;
using System.Collections.Generic;

namespace ModelDrivenAi
{
	// Remember the Name Changed from Fit to SalienceCalc!!!
	public class SalienceCalc
	{
		
		private static double ACESSIBILITY = 0.5;
		
		
		public static double calcSalience (KMeansCluster cluster_output)
		{
			
			List<PointCollection> allClusters = cluster_output.getClusters ();
			
			if (allClusters.Count < 2) {
				return 0;
			}
			
			// Splitting the current agents cluster into a single variable for easy distinction.
			PointCollection myCluster = allClusters [cluster_output.getMyClusterIndex ()];
			//allClusters.RemoveAt (cluster_output.getMyClusterIndex ());
			
			// The Weights of Fit Alpha & Beta
			double alpha = 0.8;
			double beta = 0.2;
			
			// The Kmd value calculated by the total of characteristics available (currently 3) 
			// and the maximum value they can have (currently 100)
			double kmd = Math.Sqrt (Characteristic.NUMBER_OF_CHARACTERISTICS) * 100;
			
			// The Kmcw constant currently set at 50
			double kmcw = 50;
			
			// TEMPORARY CODE!!! 
			Point my_point = null;
			foreach (Point point in myCluster) {
				if (cluster_output.myName.Equals (point.getID ())) {
					my_point = point;
				}
			}
			
			double cluster_distance = 0.0;

			// So as not to include the players own cluster in the calculation
			int compare_index = 0;
			// Calculating the distance between my centroid and out-group centroids.
			foreach (PointCollection cluster in allClusters) {
				if(compare_index != cluster_output.getMyClusterIndex())
					cluster_distance += Math.Abs (Point.FindDistance(myCluster.Centroid, cluster.Centroid));
				compare_index++;
			}
			
			// OLD VERSION OF THE FIT CALCULATION.
			//			foreach (PointCollection cluster in allClusters) {
			//				cluster_distance += (Math.Abs (Point.FindDistance (my_point, cluster.Centroid)) - 
			//				                     Math.Abs (Point.FindDistance(my_point, myCluster.Centroid)));
			//			}
			
			if(cluster_distance < 0)
				cluster_distance = 0;
			
			
			// END OF TEMPORARY CODE!
			
			// Calculating the distance between all centroid relative to his.
			//			double cluster_distance = 0.0;
			//			foreach (PointCollection cluster in allClusters) {
			//				cluster_distance += Math.Abs (Point.FindDistance (myCluster.Centroid, cluster.Centroid));
			//			}
			
			// Calculating the dispersion.
			double dispersion = CalcDispersion(myCluster);
			
			// Calculating the fit value.
			double fit = ( ( alpha * ( cluster_distance / kmd ) ) + ( beta * ( 1 - ( dispersion / kmcw ) ) ) );
			
			// Calculating Acessibility
			double accessibility = 1 - (Math.Abs (Point.FindDistance(my_point, myCluster.Centroid)) / kmd);
			
			// Calculating Salience
			double salience = fit * accessibility;
			
			Console.WriteLine("Fit: " + fit + "; Accessibility: " + accessibility + "; Salience: " + salience);
			
			return salience;
		}
		
		/**
		 * Calculates the distance between 2 clusters.
		 * */
		public static double CalcDistanceBetweenClusters (PointCollection cluster1, PointCollection cluster2)
		{
			return (Point.FindDistance (cluster1.Centroid, cluster2.Centroid));
		}
		
		/**
		 * Calculates the dispersion of one cluster.
		 * */
		public static double CalcDispersion (PointCollection cluster)
		{
			double dispersion = 0.0;
			foreach (Point p in cluster) {
				dispersion += Point.FindDistance (p, cluster.Centroid);
			}
			return (dispersion / cluster.Count);
		}
		
		/**
		 * Returns the distance of an element from the centroid.
		 * */
		public static double DistanceFromCentroid (Point p, PointCollection cluster)
		{
			return Point.FindDistance (p, cluster.Centroid);
		}
		
		public static double calcAcessibility (double fit_value)
		{
			return (fit_value * ACESSIBILITY);
		}
		
	}
}


