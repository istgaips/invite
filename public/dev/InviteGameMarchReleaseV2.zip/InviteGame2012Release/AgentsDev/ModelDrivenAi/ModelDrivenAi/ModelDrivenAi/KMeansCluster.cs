using System;
using System.Collections.Generic;

namespace ModelDrivenAi
{
	/**
	 * This class will apply a K-Means Cluster on a list of Characteristics. This will represent each individual's clustering process.
	 * */
	public class KMeansCluster
	{
		// The list of player Agents.
		InternalAgent[] agent_array;
		
		public String myName;
		
		List<PointCollection> my_Clusters;
		int mycluster_index;
		
		// This is the distance threshold which if passed increments the K in the KMeans algorithm so as to add one more cluster to 
		// minimize centroid distance.
		private static double CENTROID_DISTANCE_THRESHOLD = 10.0;
		
		private static String CENTROID_IDENTIFIER = "Centroid ";
		/**
		 * The Constructor for the KMeansCluster Function
		 * */
		public KMeansCluster (InternalAgent[] agent_array, String myName)
		{
			// Initialize the KMeansCluster with all the necessary data.
			this.agent_array = agent_array;
			this.myName = myName;
			
			// The List of Points used by our clustering algorithm.
			List<Point> dataPoints = createPointList (agent_array);
			
			// Initialize the KMeans clustering algorithm with K = 2
			int K_Value = 1;
			
			
			// The Boolean Loop
			bool cycle = true;
			while (cycle) 
			{
				// Divide points into equal clusters.
				List<PointCollection> allClusters = new List<PointCollection>();
				List<List<Point>> clusterGroups = SplitList<Point>(dataPoints, K_Value);
				
				int index_centroid = 0;
				
				// Share points between the cluster groups.
				foreach(List<Point> cluster_group in clusterGroups){
					PointCollection cluster = new PointCollection(Characteristic.NUMBER_OF_CHARACTERISTICS, CENTROID_IDENTIFIER + index_centroid);
					cluster.AddRange(cluster_group);
					cluster.UpdateCentroid();
					allClusters.Add(cluster);
					index_centroid++;
				}
				
				// Time to begin the Clustering Algorithm
				bool second_cycle = true;
				while(second_cycle)
				{
					// If no movement is made we already optimized our clustering process.
					second_cycle = false;
					
					// For all clusters
					foreach(PointCollection cluster in allClusters)
					{
						// For all points in each cluster
						
						for (int pointIndex = 0; pointIndex < cluster.Count; pointIndex++) 
						{
							Point point = cluster[pointIndex];
							
							int nearestCluster = FindNearestCluster(allClusters, point);
							if (nearestCluster != allClusters.IndexOf(cluster)) //if point has moved
							{
								if (cluster.Count > 1) //cluster shall have minimum one point
								{
									Point removedPoint = cluster.RemovePoint(point);
									allClusters[nearestCluster].AddPoint(removedPoint);
									second_cycle = true;
								}
							}
						}
					}
				}
				// Lets verify if we need to increase our K and add another cluster to the algorithm.
				//				if(incrementKMeans(allClusters)){
				//					K_Value++;
				//				}
				
				// TEMPORARY CODE TO LIMIT KMEANS TO ONLY 2 CLUSTERS!!!! REMOVE FOR DYNAMIC CLUSTERING!
				
				
				if(K_Value < 2 && incrementKMeans(allClusters)){
					K_Value++;
				}
				else {
					cycle = false;
					for(int i = 0; i < allClusters.Count; i++){
						foreach(Point p in allClusters[i]){
							if(p.getID().Equals(this.myName))
								this.mycluster_index = i;
						}
					}
					my_Clusters = allClusters;
				}
			}
		}
		
		/**
		 * Returns the List of Clusters.
		 * */
		public List<PointCollection> getClusters ()
		{
			return my_Clusters;
		}
		
		public int getMyClusterIndex ()
		{
			return mycluster_index;
		}
		
		/**
		 * This function creates a point list of all our agents.
		 * */
		public List<Point> createPointList (InternalAgent[] agents)
		{
			List<Point> point_list = new List<Point>();
			double[] new_point;
			foreach(InternalAgent a in agents){
				new_point = new double[a.getCharacteristics().Count];
				for(int i = 0; i < new_point.Length; i++){
					new_point[i] = a.getCharacteristics()[i].getValue();
				}
				point_list.Add(new Point(new_point, a.getName()));
			}
			return point_list;
		}
		
		
		/**
		 * Splits a list evenly in accordance to the groupCount
		 * */
		public static List<List<T>> SplitList<T>(List<T> items, int groupCount)
		{
			List<List<T>> allGroups = new List<List<T>>();
			
			//split the list into equal groups
			int startIndex = 0;
			int groupLength = (int)Math.Round((double)items.Count / (double)groupCount, 0);
			while (startIndex < items.Count)
			{
				List<T> group = new List<T>();
				group.AddRange(items.GetRange(startIndex, groupLength));
				startIndex += groupLength;
				
				//adjust group-length for last group
				if (startIndex + groupLength > items.Count)
				{
					groupLength = items.Count - startIndex;
				}
				
				allGroups.Add(group);
			}
			
			//merge last two groups, if more than required groups are formed
			if (allGroups.Count > groupCount && allGroups.Count > 2)
			{
				allGroups[allGroups.Count - 2].AddRange(allGroups[allGroups.Count-1]);
				allGroups.RemoveAt(allGroups.Count - 1);
			}
			
			return (allGroups);
		}
		
		
		/**
		 * Finds the nearest cluster for the point.
		 * */
		public static int FindNearestCluster(List<PointCollection> allClusters, Point point)
		{
			double minimumDistance = 0.0;
			int nearestClusterIndex = -1;
			
			for (int k = 0; k < allClusters.Count; k++) //find nearest cluster
			{
				double distance = Point.FindDistance(point, allClusters[k].Centroid);
				if (k == 0)
				{
					minimumDistance = distance;
					nearestClusterIndex = 0;
				}
				else if (minimumDistance > distance)
				{
					minimumDistance = distance;
					nearestClusterIndex = k;
				}
			}
			
			return (nearestClusterIndex);
		}
		
		
		/**
		 * Returns the farthest point from a centroid.
		 * */
		public static Point GetFarthestPoint (PointCollection cluster)
		{
			double current_max = 0.0;
			Point farthest_point = null;
			foreach (Point p in cluster) {
				double distance = Point.FindDistance (p, cluster.Centroid);
				if(current_max == 0.0){
					farthest_point = p;
				}
				else if (distance > current_max) {
					farthest_point = p;
					current_max = distance;
				}
			}
			return farthest_point;
		}
		
		/**
		 * Returns the distance of the farthest point of this centroid.
		 * */
		public static double GetFarthestPointDistance (PointCollection cluster)
		{
			return (Point.FindDistance (GetFarthestPoint (cluster), cluster.Centroid));
		}
		
		/**
		 * This function verifies if there are any points that goes over the CENTROID_DISTANCE_THRESHOLD. If so
		 * this means that we increment the K in our KMeans algorithm adding one more cluster to our algorithm.
		 * */
		public bool incrementKMeans (List<PointCollection> allClusters)
		{
			foreach (PointCollection p in allClusters) {
				if(GetFarthestPointDistance(p) > CENTROID_DISTANCE_THRESHOLD){
					return true;
				}
			}
			return false;
		}
		
		public override string ToString ()
		{
			int index = 0;
			string str = "";
			foreach (PointCollection p in my_Clusters) {
				str += "Cluster " + index + "\r\n";
				str += p.ToString ();
				index++;
			}
			return str;
		}
		
	}
}

