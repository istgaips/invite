using System;

namespace ModelDrivenAi
{
	public class CSite: Characteristic
	{
		/**
		 * The starting site for the Agents will influence the clustering algorithm.
		 **/
		private CSite (String name) : base(name)
		{
			// Do Nothing as of Yet
		}
		
		
		public static CSite CampSiteFactory (String name)
		{
			if (name.Equals(INVITE.Game.Instance.GameConfiguration.Teams[0].Name)) {
				CSite camp = new CSite ("CS1");
				camp.setValue(100.0);
				return camp;
			} else {
				CSite camp = new CSite ("CS2");
				camp.setValue(0.0);
				return camp;
			}
		}
	}
}

