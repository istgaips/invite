using System;
using INVITE;
using ION.Agents;
using System.Linq;
using System.Threading;

namespace INVITE.Agents
{
	public class SatisfactionAgent : Player
	{		
		private SocialComparison socialComparison;
		private SocialIdentification socialIdentification;
		
		private int minDelay = 2;
		private int maxDelay = 5;
		private bool isMoving;
		
		public SatisfactionAgent(string name, ITeam team, uint playerTimePerDay)
			: base (name, team, playerTimePerDay)
		{
			this.isMoving = false;
			this.Mover.Started += this.OnMoveStarted;
			this.Mover.Stopped += this.OnMoveStopped;
			this.TimeLeftToday.ValueChanged += this.HoursValueChanged;	
			
			this.socialComparison = new SocialComparison(this);
			this.socialIdentification = new SocialIdentification(this, 0.5f);
		}
		
		
		public void OnMoveStarted(ION.Agents.IStartedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) {
			this.isMoving = true;
		}
		
		public void OnMoveStopped(ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) 
		{
			this.isMoving = false;
			this.DecideAction();
		}
		
		public void HoursValueChanged (ION.Agents.IValueChangedEvent<uint> evt)
		{
			if (!this.isMoving)
			{
				this.DecideAction();
			}
		}

		private void DecideAction()
		{
			if(this.TimeLeftToday.Value > 0) // Agent has time to gather resources
			{
				if(this.Locale.Value is IResourceSite) // Agent at resource site. Gather resources
				{
					this.PlayMiniGame();
				}
				else // Move to resource site
				{
					this.Mover.Start(new MoveTo(this.RandomResourceSite()));
				} 
			}
			else if (this.Locale.Value != this.Team.CampSite) // No more time left and not at camp site. Go to camp site 
			{
				this.Mover.Start(new MoveTo(this.Team.CampSite));
			}
		}
		
		public void PlayMiniGame ()
		{
			uint timeLeftToday = this.TimeLeftToday.Value;
			
			uint wood = timeLeftToday;
			uint gold = 0;
			int delayInt = random.Next(this.minDelay, this.maxDelay);
			uint delayUInt = Convert.ToUInt32(delayInt);
			
			this.MiniGamePlayer.Start(new MiniGame(wood, gold, delayUInt));
		}
	}
}

