using System;

namespace INVITE.Agents
{
	public class Satisfaction
	{
		public Satisfaction ()
		{
		}
	}
}

