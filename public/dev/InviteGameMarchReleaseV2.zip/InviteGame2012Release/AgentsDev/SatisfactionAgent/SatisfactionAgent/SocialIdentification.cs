//Social Identification Module
//we will compare our average number of wood/gold with our teamMates
//if they play more wood than me the result will be > 0
//if they play less wood than me the result will be < 0
//if the result is = 0 we have the same values, and the identification is "perfect".

using System;
using System.Collections.Generic;
using System.Linq;
using INVITE;
using ION.Meta;
using ION.Agents;
using ION.Collections;

namespace INVITE.Agents
{
	public class SocialIdentification : Module
	{
		private List<double> myWoodByRound;
		private List<double> myTeamWoodByRoundWithoutMe;
		private double mySocialIdentification;
		
		private uint myTeamWoodLastRoundWithoutMe;
		private uint myWoodLastRound;
		
		private IPlayer agent;
		private double lastRoundWeight;
		
		public SocialIdentification (IPlayer player, double lastRoundWeight)
		{
			this.myWoodByRound = new List<double>();
			this.myTeamWoodByRoundWithoutMe = new List<double>();
			this.mySocialIdentification = 0;
			Island.Instance.DaysLeftToEruption.ValueChanged += this.AnotherDay;
			this.myTeamWoodLastRoundWithoutMe = 0;
			this.myWoodLastRound = 0;
			this.agent = player;
			this.lastRoundWeight = lastRoundWeight;
		}
		
		public double Value { get { return this.mySocialIdentification;	} }
		
		private double myAverageWood 
		{
			get {
				uint myAverage = 0;
				foreach(uint val in myWoodByRound) {
					myAverage += val;
				}
				return (myAverage / myWoodByRound.Count);
			}
			
		}
		
		private double myTeamAverageWood 
		{	
			get {
				uint teamAverage = 0;
				foreach(uint val in myTeamWoodByRoundWithoutMe) {
					teamAverage += val;
				}
				return (teamAverage / myTeamWoodByRoundWithoutMe.Count);
			}
			
		}
		
		
		private void AnotherDay(ION.Agents.IValueChangedEvent<uint> evt) 
		{
			//day changed, so we know that all players have ended their day!
			uint myRound = this.agent.WoodCollected.Value - this.myWoodLastRound;
			this.myWoodByRound.Add (myRound);
			
			uint myTeamRoundWithMe = this.agent.Team.BuildRaftTask.WoodGathered - this.myTeamWoodLastRoundWithoutMe;
			
			uint myTeamRoundWithoutMe = myTeamRoundWithMe - myRound;
			
			int teamNumbPlayers = Game.Instance.GameConfiguration.Teams[0].Players.Count;
			
			double myTeamAverageWithoutMeThisRound = myTeamRoundWithoutMe / (teamNumbPlayers - 1);
			
			this.myTeamWoodByRoundWithoutMe.Add(myTeamAverageWithoutMeThisRound);
			
			double thisRoundIdentification = myTeamAverageWithoutMeThisRound - myRound;
			double averageIdentification = myTeamAverageWood - myAverageWood;
			
			this.mySocialIdentification = thisRoundIdentification * lastRoundWeight + averageIdentification * (1-lastRoundWeight);
		}
	}
}

