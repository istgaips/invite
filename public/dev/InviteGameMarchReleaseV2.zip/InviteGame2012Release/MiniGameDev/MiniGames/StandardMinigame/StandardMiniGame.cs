using System;
using UnityEngine;
using System.Collections;

public class StandardMiniGame : IMiniGame
{
	public StandardMiniGame (uint WoodPerTimeUnit, uint GoldPerTimeUnit)
		: base (WoodPerTimeUnit,GoldPerTimeUnit)
	{
	}
	
	private int GUIWidth = 500; 						// Defines the GUI background width
	private int GUIHeight = 300; 						// Defines the GUI background height
	private int GUIPosX;// = (Screen.width-GUIWidth)/2; 	// Defines the GUI position on the X axis
	private int GUIPosY; //= (Screen.height-GUIHeight)/2; 	// Defines the GUI position on the Y axis
	private int buttonWidth = 100;
	private int buttonHeight = 30;
	private int textFieldWidth = 32;
	private int textFieldHeight = 32;
	
	override public void PlayMinigame(uint hoursleft){
		hoursSpendWood = 0;
		hoursSpendGold = 0;
		this.hoursLeft=hoursleft;
		GUIPosX = (Screen.width-GUIWidth)/2;
		GUIPosY = (Screen.height-GUIHeight)/2;
	}	
	
	private float widthMenuWindow;
	private float heightMenuWindow;
	private Rect mainMenuWindow;
	
	override public void Draw ()
	{
				GUI.skin = GUIStyles.customSkin;	
		widthMenuWindow = Screen.width - ((Screen.width/8) * 2.2f);
		heightMenuWindow = Screen.height - ((Screen.height/8) * 2);
		widthMenuWindow = widthMenuWindow - (int)(0.25* widthMenuWindow);
		mainMenuWindow = new Rect(Screen.width/2 - widthMenuWindow / 2, Screen.height/2 - heightMenuWindow / 2, widthMenuWindow , heightMenuWindow );
		
		GUILayout.Window(0, mainMenuWindow, DoMainMenu, "");
	}
	
void DoMainMenu(int windowId){
		uint collectedGameWood = woodCollectedPerHour * hoursSpendWood;
		uint collectedGameGold = goldCollectedPerHour * hoursSpendGold;
		
		GUILayout.Space(40);
		GUILayout.Label("Collecting Resources", GUIStyles.label2MenuStyle);
		
		GUILayout.BeginVertical(); 
			// Draws the mini-game hours left information and question
			GUILayout.Label(GUITextLabels.MiniGameText1 + " " + (hoursLeft - hoursSpendWood - hoursSpendGold) + " " + GUITextLabels.MiniGameText2 + ". \n" + GUITextLabels.MiniGameText9 , GUIStyles.labelMenuStyle4); 
		
			GUILayout.BeginHorizontal(); 
				GUILayout.FlexibleSpace(); 
				GUILayout.BeginVertical(); 
					GUILayout.Label("Wood", GUIStyles.label2MenuStyle); 
					GUILayout.BeginHorizontal();
						GUILayout.Label(GUIStyles.bigWoodImage, "Box");
						GUILayout.Space(5); 
						GUILayout.BeginVertical(); 
							GUILayout.FlexibleSpace(); 
							GUILayout.Label("" + hoursSpendWood, GUIStyles.labelMenuStyle, GUILayout.Width(32));
							GUILayout.FlexibleSpace(); 
						GUILayout.EndVertical(); 
						GUILayout.Space(5); 
						GUILayout.BeginVertical();
							if(GUILayout.Button(GUIStyles.upWoodImage)){
								addUnitWood(); 
							}
							if(GUILayout.Button(GUIStyles.downWoodImage)){
								removeUnitWood(); 
							}
						GUILayout.EndVertical(); 
					GUILayout.EndHorizontal(); 
				GUILayout.EndVertical();
		
				GUILayout.Space(widthMenuWindow/8);
		
				GUILayout.BeginVertical(); 
					GUILayout.Label("Gold", GUIStyles.label2MenuStyle); 
					GUILayout.BeginHorizontal();
						GUILayout.Label(GUIStyles.bigGoldImage, "Box");
						GUILayout.Space(5); 
						GUILayout.BeginVertical(); 
							GUILayout.FlexibleSpace(); 
							GUILayout.Label("" + hoursSpendGold,  GUIStyles.labelMenuStyle, GUILayout.Width(32));
							GUILayout.FlexibleSpace(); 
						GUILayout.EndVertical();
						GUILayout.Space(5); 
						GUILayout.BeginVertical();
							if(GUILayout.Button(GUIStyles.upGoldImage)){
								addUnitGold(); 
							}
							if(GUILayout.Button(GUIStyles.downGoldImage)){
								removeUnitGold(); 
							}
						GUILayout.EndVertical(); 
					GUILayout.EndHorizontal(); 
				GUILayout.EndVertical(); 
				GUILayout.FlexibleSpace(); 
		
			GUILayout.EndHorizontal(); 
		
			// Draws the collected resources information
			GUILayout.Label(GUITextLabels.MiniGameText7 + ": " + collectedGameWood + " " + GUITextLabels.MiniGameText4 + " " + GUITextLabels.MiniGameText8 + " " + collectedGameGold + " " + GUITextLabels.MiniGameText5, GUIStyles.labelMenuStyle4); 
		 
		GUILayout.FlexibleSpace();
		
		GUILayout.BeginHorizontal(); 
		if (GUILayout.Button (GUITextLabels.MiniGameConfirmText6, GUIStyles.middleButtonMenuStyle))
		{
			clickCancel();
		}
		if (GUILayout.Button ("OK", GUIStyles.middleButtonMenuStyle))
		{
			clickOK();
		}
		GUILayout.EndHorizontal(); 
		
		GUILayout.EndVertical();
	}
	
	
	public void addUnitWood(){
		if (hoursSpendWood < hoursLeft)
		{
			hoursSpendWood = hoursSpendWood+1;
		}
		if (hoursSpendWood + hoursSpendGold > hoursLeft)
		{
			hoursSpendGold = hoursSpendGold-1;
		}
	}
	
	public void removeUnitWood(){
		if (hoursSpendWood > 0)
		{
			hoursSpendWood = hoursSpendWood-1;
		}
	}
	
	public void addUnitGold(){
		if (hoursSpendGold < hoursLeft)
		{
			hoursSpendGold = hoursSpendGold+1;
		}
		if (hoursSpendGold + hoursSpendWood > hoursLeft)
		{
			hoursSpendWood = hoursSpendWood-1;
		}
		
	}
	
	public void removeUnitGold(){
		if (hoursSpendGold > 0)
		{
			hoursSpendGold= hoursSpendGold-1;
		}
	}
	
	public void Draw2 ()
	{
	
		
		uint collectedGameWood = woodCollectedPerHour * hoursSpendWood;
		uint collectedGameGold = goldCollectedPerHour * hoursSpendGold;
		
		Color backgroundColor = new Color(0.4f, 0.4f, 0.4f, 1.0f); // Light Grey
		
		// Draws the mini-game background
		GUI.backgroundColor = backgroundColor;
		GUI.Box (new Rect (GUIPosX, GUIPosY, GUIWidth, GUIHeight), "Bla Bla Bla", GUIStyles.backgroundBoxStyle);
		
		// Draws the mini-game hours left information and question
		GUI.Label (new Rect (GUIPosX, GUIPosY+10, GUIWidth, GUIHeight/2), GUITextLabels.MiniGameText1 + " " + (hoursLeft - hoursSpendWood - hoursSpendGold) + " " + GUITextLabels.MiniGameText2 + ". \n" + GUITextLabels.MiniGameText2, GUIStyles.upperTextStyle);
		
		// Draws the mini-game resource number of hours spend information
		GUI.Label (new Rect (GUIPosX, GUIPosY+GUIHeight/3, GUIWidth/2, GUIHeight/3*2), GUITextLabels.MiniGameText4 + ":", GUIStyles.upperTextStyle);
		GUI.Label (new Rect (GUIPosX+GUIWidth/2, GUIPosY+GUIHeight/3, GUIWidth/2, GUIHeight/3*2), GUITextLabels.MiniGameText5 + ":", GUIStyles.upperTextStyle);
		
		// Draws the wood and gold text fields
		GUI.Label (new Rect (GUIPosX+GUIWidth*1/4-textFieldWidth/2, GUIPosY+GUIHeight/3+textFieldHeight, textFieldWidth, textFieldHeight), "" + hoursSpendWood, GUIStyles.bigTextFieldStyle);
		GUI.Label (new Rect (GUIPosX+GUIWidth*3/4-textFieldWidth/2, GUIPosY+GUIHeight/3+textFieldHeight, textFieldWidth, textFieldHeight), "" + hoursSpendGold, GUIStyles.bigTextFieldStyle);
	
		// Draws the collected resources information
		GUI.Label (new Rect (GUIPosX, GUIPosY+GUIHeight*3/5+10, GUIWidth, GUIHeight/3*2), GUITextLabels.MiniGameText7 + ": " + collectedGameWood + " " + GUITextLabels.MiniGameText4 + " " + GUITextLabels.MiniGameText8 + " " + collectedGameGold + " " + GUITextLabels.MiniGameText5, GUIStyles.upperTextStyle);
		
		
		// Wood arrow buttons
		if (GUI.Button (new Rect (GUIPosX+GUIWidth*1/4-textFieldWidth/2+50, GUIPosY+GUIHeight/3+textFieldHeight-20, textFieldWidth, textFieldHeight), GUIStyles.arrowUpStyle))
		{
			if (hoursSpendWood < hoursLeft)
			{
				hoursSpendWood = hoursSpendWood+1;
			}
			if (hoursSpendWood + hoursSpendGold > hoursLeft)
			{
				hoursSpendGold = hoursSpendGold-1;
			}
		}
		if (GUI.Button (new Rect (GUIPosX+GUIWidth*1/4-textFieldWidth/2+50, GUIPosY+GUIHeight/3+textFieldHeight+20, textFieldWidth, textFieldHeight), GUIStyles.arrowDownStyle))
		{
			if (hoursSpendWood > 0)
			{
				hoursSpendWood = hoursSpendWood-1;
			}
		}
		
		// Gold arrow buttons
		if (GUI.Button (new Rect (GUIPosX+GUIWidth*3/4-textFieldWidth/2+50, GUIPosY+GUIHeight/3+textFieldHeight-20, textFieldWidth, textFieldHeight), GUIStyles.arrowUpStyle))
		{
			if (hoursSpendGold < hoursLeft)
			{
				hoursSpendGold = hoursSpendGold+1;
			}
			if (hoursSpendGold + hoursSpendWood > hoursLeft)
			{
				hoursSpendWood = hoursSpendWood-1;
			}
		}
		
		if (GUI.Button (new Rect (GUIPosX+GUIWidth*3/4-textFieldWidth/2+50, GUIPosY+GUIHeight/3+textFieldHeight+20, textFieldWidth, textFieldHeight), GUIStyles.arrowDownStyle))
		{
			if (hoursSpendGold > 0)
			{
				hoursSpendGold = hoursSpendGold-1;
			}
		}
		
			if (GUI.Button (new Rect (GUIPosX+GUIWidth/2-buttonWidth-10, GUIPosY+GUIHeight*3/4+buttonHeight/2, buttonWidth, buttonHeight), GUITextLabels.MiniGameConfirmText6))
			{
				clickCancel();
			}
			// Draws the  button
			if (GUI.Button (new Rect (GUIPosX+(GUIWidth-buttonWidth)/2+buttonWidth-10, GUIPosY+GUIHeight*3/4+buttonHeight/2, buttonWidth, buttonHeight), "OK"))
			{
				clickOK ();
			}
		
		/*if (hoursSpendWood + hoursSpendGold == hoursLeft)
		{
			// Draws the Cancel button
			if (GUI.Button (new Rect (GUIPosX+GUIWidth/2-buttonWidth-10, GUIPosY+GUIHeight*3/4+buttonHeight/2, buttonWidth, buttonHeight), GUITextLabels.MiniGameConfirmText6))
			{
				this.CancelClicked();
			}
			// Draws the  button
			if (GUI.Button (new Rect (GUIPosX+(GUIWidth-buttonWidth)/2+buttonWidth-10, GUIPosY+GUIHeight*3/4+buttonHeight/2, buttonWidth, buttonHeight), "OK"))
			{
				this.OkClicked(hoursSpendGold, hoursSpendWood);
			}
		}
		else{
			if (GUI.Button (new Rect (GUIPosX+(GUIWidth-buttonWidth)/2, GUIPosY+GUIHeight*3/4+buttonHeight/2, buttonWidth, buttonHeight), "Cancel"))
			{
				this.CancelClicked();
			}
		}*/
	}
}	