//Social Comparison.
//We will check what is our (team) amount of wood in the population (all teams)
//if we are winning the game we have 1 returning. The Higher the number the higher the place in the game our team is.

using System;
using System.Linq;
using INVITE;
using ION.Collections;
using ION.Meta;
using ION.Agents;
using System.Collections.Generic;
using System.Collections;

namespace INVITE.Agents
{
	public class SocialComparison : Module
	{
		private IPlayer agent;
		private uint myPlace;
		
		public SocialComparison (IPlayer player)
		{
			this.agent = player;
			this.myPlace = 1;
			Island.Instance.DaysLeftToEruption.ValueChanged += this.AnotherDay;
		}
		
		public double Value { get { return this.myPlace; } }
		
		private void AnotherDay(ION.Agents.IValueChangedEvent<uint> evt) 
		{
			ITeam myTeam = this.agent.Team;
				
			IEnumerable<ITeam> teamsEnumerable = Game.Instance.Teams;
			IEnumerator<ITeam> teamsEnumerator = teamsEnumerable.GetEnumerator();
			while(teamsEnumerator.MoveNext()) {
				ITeam team = teamsEnumerator.Current;
				if(myTeam == team) {
					continue;
				}
				
				if(team.BuildRaftTask.WoodGathered > myTeam.BuildRaftTask.WoodGathered) {
					this.myPlace ++;
				}			
			}
		}
	}
}

