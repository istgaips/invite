using System;

namespace INVITE.Agents
{
	public interface Module
	{
		double Value {get;}
	}
}

