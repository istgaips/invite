﻿using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;

using System.Text;
using Smile;
using Smile.Learning;

namespace INVITE.Agents
{
    public class LogProcessing
    {
		
        
       
        
        const string network_file_name = "exp1.xdsl";

        const string EVENT_MOVE = "EVENT_MOVE";
        const string EVENT_MATCH_STARTED = "EVENT_GAME_STARTED-";
        const string init = "init";
        const string Teams = "Teams-";
        const string playerName = "Name-";
        const string TEAMstr = "TEAM-";
		const string team_name_str= "TEAM_NAME";
        const string one = "1";
        const string PlayersPerTeam = "PlayersPerTeam-";
        const string player_str = "PLAYER-";
        const string TA_str = "TimeActions-";
        const string Wood_pa_str="WOOD_PER_ACTION-";
        const string Gold_pa_str="GOLD_PER_ACTION-";
        const string Days_to_erupt="DAYS_TO_ERUPTION-";
        const string total_raft_wood="TOTAL_RAFT_WOOD-";
        const string event_minigame_started = "EVENT_MINIGAME_STARTED-";
        const string event_day_forward="EVENT_DAY_FORWARD-";
        const string event_match_ended="EVENT_MATCH_ENDED";
        const string state_team_str="STATE_TEAM";
        const string priming_str = "Priming-";
        const string raftprogress_str="RaftProgress-";
        const string stateplayer_str="STATE_PLAYE";
        const string wood_str="Wood-";
        const string gold_str = "Gold-";
        const string raft_prog_str = "RaftProgression_";
        const string gold_prog_str = "GoldCollected_";
        const string GamePhase = "Phase_";
        const string identity_str = "Identity";
        const string action_str = "Action_";
        const string Trait_Agreeableness_str = "Trait_Agreeableness";
        const string Raft_node_1 = "VeryFew";
        const string Raft_node_2 = "Few";
        const string Raft_node_3 = "HalfWay";
        const string Raft_node_4 = "High";
        const string Raft_node_5 = "VeryHigh";
        const string Gold_node_1 = "VeryFew";
        const string Gold_node_2 = "Few";
        const string Gold_node_3 = "HalfWay";
        const string Gold_node_4 = "High";
        const string Gold_node_5 = "VeryHigh";
        const string Action_node_1 = "DefectBarely";
        const string Action_node_2 = "Defect";
        const string Action_node_3 = "StronglyDefect";
        const string Action_node_4 = "VeryStronglyDefect";
        const string phase_node_1 = "Beginning";
        const string phase_node_2 = "VeryEarly";
        const string phase_node_3 = "Early";
        const string phase_node_4 = "HalfWay";
        const string phase_node_5 = "Late";
        const string phase_node_6 = "VeryLate";
        const string phase_node_7 = "End";

        const string player_id_match = "PLAYER-ID_";





        public static string gamePhaseIndex(int _day, int total_days)
        {
            float game_progress = (float)_day / (float)total_days;
            if (game_progress <= 0.15)
            {
                return phase_node_1;
            }
            else if (game_progress > 0.15 && game_progress <=0.30)
            {
                return phase_node_2;
            }
            else if (game_progress > 0.30 && game_progress <= 0.45)
            {
                return phase_node_3;
            }
            else if (game_progress > 0.45 && game_progress <= 0.60)
            {
                return phase_node_4;
            }
            else if (game_progress > 0.60 && game_progress <= 0.74)
            {
                return phase_node_5;
            }
            else if (game_progress > 0.74 && game_progress <= 0.90)
            {
                return phase_node_6;
            }
            else if (game_progress > 0.90)
            {
                return phase_node_7;
            }
            return "Invalid value";
        }

        public static string action_description(int _wood,int _time)
        {
            float woodpercent = (float)_wood / (float)_time;
            if(woodpercent<=0.25)
                return Action_node_4;
            else if (woodpercent >0.25 && woodpercent <0.5)
            {
                return Action_node_3;
            }
            else if (woodpercent >= 0.5 && woodpercent <= 0.75)
            {
                return Action_node_2;
            }
            else 
            {
                return Action_node_1;
            }
        }

        public static string raft_progress_index(int wood, int raft)
        {

       
            float raft_progress = (float)wood / (float)raft;

            if (raft_progress <= 0.20)
            {
                return Raft_node_1;
            }
            else if (raft_progress > 0.20 && raft_progress <= 0.4)
            {
                return Raft_node_2;
            }
            else if (raft_progress > 0.4 && raft_progress <= 0.6)
            {
                return Raft_node_3;
            }
            else if (raft_progress > 0.6 && raft_progress <= 0.8)
            {
                return Raft_node_4;
            }
            else if (raft_progress > 0.8)
            {
                return Raft_node_5;
            }
  
      
            return "Invalid value";
        }

        public static string gold_index(int gold, int total_gold)
        {

            float gold_progress = (float)gold / (float)total_gold;
            if (gold_progress <= 0.15)
            {
                return Gold_node_1;
            }
            else if (gold_progress > 0.15 && gold_progress <= 0.3)
            {
                return Gold_node_2;
            }
            else if (gold_progress > 0.3 && gold_progress <= 0.5)
            {
                return Gold_node_3;
            }
            else if (gold_progress > 0.5 && gold_progress <= 0.6)
            {
                return Gold_node_4;
            }
            else if (gold_progress > 0.6 )
            {
                return Gold_node_5;
            }
            return "Invalid value";
        }

        public  bool get_Params(ref StreamReader _sr, ref int count,ref int _numberTeams, ref int _wood_pa, ref int _gold_pa, ref int _TimeActions, ref int _days_left,ref int _total_raft_wood, ref List<String> _list,ref int _primed)
        {
            String line;
            bool ret = false;
            bool match_started = false;
            int TEAM = 0;
           
            
            while ((line = _sr.ReadLine()) != null && !line.Contains(EVENT_MOVE) )
            {
                ret = true;

                if (line.Contains(EVENT_MATCH_STARTED))
                {
                    match_started = true;
                }
                if (line.Contains(Teams) && match_started)
                {
                    String numT = line.Substring(Teams.Length);
                    _numberTeams = Convert.ToInt32(numT);
                 
                }

                else if (line.Contains(priming_str) && match_started)
                {
                    string str=line.Substring(priming_str.Length);
                    if (string.Compare(str, "Yes") == 0)
                    {
                        _primed = 1;
                    }
                    else
                    {
                        _primed = 0;
                    }

                }
                else if (line.Contains(TEAMstr) && match_started)
                {
                    TEAM++;
                  
                }
                else if (line.Contains(player_id_match) && line.Contains("Human Player") && match_started)
                {
                
                    _list.Add(line.Substring(player_str.Length));
                   
                }
                else if (line.Contains(TA_str) && match_started)
                {
                    
                     _TimeActions= Convert.ToInt32(line.Substring(TA_str.Length));
                
                }
                else if (line.Contains(Wood_pa_str) && match_started)
                {
                    _wood_pa = Convert.ToInt32(line.Substring(Wood_pa_str.Length));
                     

                }
                else if (line.Contains(Gold_pa_str) && match_started)
                {
                    _gold_pa = Convert.ToInt32(line.Substring(Gold_pa_str.Length));
                   

                }
                else if (line.Contains(Days_to_erupt) && match_started)
                {
                    _days_left = Convert.ToInt32(line.Substring(Days_to_erupt.Length));

                }
                else if (line.Contains(total_raft_wood) && match_started)
                {
                    String total_raft = line.Substring(total_raft_wood.Length);
                    _total_raft_wood = Convert.ToInt32(total_raft);
                   
                }


               

            }

           
            return ret;
        }
         
        public  bool get_Info(ref StreamReader sr,ref List<String> lista_jogadores,ref  List<List<List<int>>> lista_accoes,ref int numPlayers, ref int total_wood, ref int wood_pa,ref int gold_pa){
            int team=0;
            int player=0;
            int days=0;
            int raft = 0;
            int gold = 0;
            int wood = 0;
            bool notBot = false;
            String name=""; 
         
           String log_line;
            bool jump_minigame=false;
  
            while ((log_line = sr.ReadLine()) != null)
            {
                
                
                if (log_line.Contains(event_minigame_started)) jump_minigame = true;
                else if (log_line.Contains(event_day_forward) || log_line.Contains(event_match_ended))
                {
                    team = 0;
                    player = 0;
                    days++;
                    notBot = false;
                    jump_minigame = false;
                    for(int i=0;i<numPlayers;i++)
                    {
                       
                        lista_accoes[i].Add(new List<int>(8));
                        
                    }
                }
                else if (log_line.Contains(state_team_str)) team++;
                else if (log_line.Contains(raftprogress_str))
                {
                   
                    String[] aux1 = log_line.Substring(raftprogress_str.Length).Split('/');
                    raft = Convert.ToInt32(aux1[0]);
                }
                else if (log_line.Contains(playerName))
                {
                    
                    name= log_line.Substring(playerName.Length);

                    //despistar Name- da equipa "T1" OU "T2"
                    if ( !name.Contains(team_name_str))
                    {
                        notBot = false;
                       for(int i = 0;  i < lista_jogadores.Count; i++)

                        {
                            if (lista_jogadores[i].Contains(name))
                            {
                                Console.WriteLine(name);
                                notBot = true;
                                player++;
                              
                            }
                          
                        }

                    }
                
                   
                }
                else if (log_line.Contains(wood_str) && !jump_minigame && notBot )
                {
                     wood = Convert.ToInt32(log_line.Substring(wood_str.Length));
                 
                         lista_accoes[player - 1][days - 1].Add(raft);
                         lista_accoes[player - 1][days - 1].Add(wood);
                     
                        notBot = true;
                      }
                else if (log_line.Contains(gold_str) && !jump_minigame && notBot )
                {
                     gold = Convert.ToInt32(log_line.Substring(gold_str.Length));


                        lista_accoes[player - 1][days - 1].Add(gold);
                        if (days > 1)
                        {

                            lista_accoes[player - 1][days - 1].Add(raft - lista_accoes[player - 1][days - 2][0]);
                            lista_accoes[player - 1][days - 1].Add(wood - lista_accoes[player - 1][days - 2][1]);


                            lista_accoes[player - 1][days - 1].Add(gold - lista_accoes[player - 1][days - 2][2]);
                            lista_accoes[player - 1][days - 1].Add((wood - lista_accoes[player - 1][days - 2][1])/wood_pa);
                            lista_accoes[player - 1][days - 1].Add((gold - lista_accoes[player - 1][days - 2][2])/gold_pa);

                        }
                        else
                        {
                            
                            lista_accoes[player - 1][days - 1].Add(raft);
                            lista_accoes[player - 1][days - 1].Add(wood);
                            lista_accoes[player - 1][days - 1].Add(gold);
                            lista_accoes[player - 1][days - 1].Add(wood/wood_pa);
                            lista_accoes[player - 1][days - 1].Add(gold/gold_pa);

                        }
                    //se jpgador ja saiu da ilha, = sem accoes
             
                        notBot = true;
                    
                             Console.WriteLine("player {0} {1} {2} {3} {4} {5} {6} {7}", lista_accoes[player - 1][days - 1][0], lista_accoes[player - 1][days - 1][1], lista_accoes[player - 1][days - 1][2], lista_accoes[player - 1][days - 1][3], lista_accoes[player - 1][days - 1][4], lista_accoes[player - 1][days - 1][5], lista_accoes[player - 1][days - 1][6], lista_accoes[player - 1][days - 1][7]);
                       //se wood e gold forem 0 significa que o jogo ja acabou
                      //  if (lista_accoes[player - 1][days - 1][6] == 0 && lista_accoes[player - 1][days - 1][7] == 0)
        
 
                }
                

               
            }
            return true;
        }

         public  Network create_Network1(String init_file,String abstract_file, int days)
        {
            Network net = new Network();
            try
            {
                double[] wood, gold, action, day;
                double[] wood_init, gold_init, action_init, day_init,identity;
                Network abs=new Network();
                Network ini = new Network();
                ini.ReadFile(init_file);
                abs.ReadFile(abstract_file);
               
                wood=abs.GetNodeDefinition(raft_prog_str + one);
                gold = abs.GetNodeDefinition(gold_prog_str + one);
                day = abs.GetNodeDefinition(GamePhase + one);
                action = abs.GetNodeDefinition(action_str + one);
               
                wood_init = ini.GetNodeDefinition(raft_prog_str + init);
                gold_init = ini.GetNodeDefinition(gold_prog_str + init);
                day_init = ini.GetNodeDefinition(GamePhase + init);
                action_init = ini.GetNodeDefinition(action_str + init);
                identity = ini.GetNodeDefinition(identity_str);
          
                net.AddNode(Network.NodeType.Cpt, identity_str);
                net.SetOutcomeId(identity_str, 0, "Strong");
                net.SetOutcomeId(identity_str, 1, "Weak");

                net.SetNodePosition(identity_str, 550, 20, 50, 50);
                net.SetNodeBgColor(identity_str, Color.Orange);
                net.SetNodeDefinition(identity_str, identity);

                for (int j = 1; j <= days; j++)
                {
                    //create node for the raft progress
           

                    net.AddNode(Network.NodeType.Cpt, raft_prog_str + j.ToString());
                    net.AddOutcome(raft_prog_str + j.ToString(), Raft_node_1);
                    net.AddOutcome(raft_prog_str + j.ToString(), Raft_node_2);
                    net.AddOutcome(raft_prog_str + j.ToString(), Raft_node_3);
                    net.AddOutcome(raft_prog_str + j.ToString(), Raft_node_4);
                    net.AddOutcome(raft_prog_str + j.ToString(), Raft_node_5);
                    net.DeleteOutcome(raft_prog_str + j.ToString(), 0);
                    net.DeleteOutcome(raft_prog_str + j.ToString(), 0);
                    net.SetNodePosition(raft_prog_str + j.ToString(), j * 500, 300, 150, 50);
                    net.SetNodeBgColor(raft_prog_str + j.ToString(), Color.Green);
                    if (j == 1)
                    {
                        net.SetNodeDefinition(raft_prog_str + j.ToString(), wood_init);
                    }
                    else
                    {
                        net.AddArc(raft_prog_str + (j - 1).ToString(), raft_prog_str + j.ToString());
                    }
                        //gold
                    net.AddNode(Network.NodeType.Cpt, gold_prog_str + j.ToString());
                    net.AddOutcome(gold_prog_str + j.ToString(), Gold_node_1);
                    net.AddOutcome(gold_prog_str + j.ToString(), Gold_node_2);
                    net.AddOutcome(gold_prog_str + j.ToString(), Gold_node_3);
                    net.AddOutcome(gold_prog_str + j.ToString(), Gold_node_4);
                    net.AddOutcome(gold_prog_str + j.ToString(), Gold_node_5);
                    net.DeleteOutcome(gold_prog_str + j.ToString(), 0);
                    net.DeleteOutcome(gold_prog_str + j.ToString(), 0);
                    if (j == 1)
                    {
                        net.SetNodeDefinition(gold_prog_str + j.ToString(), gold_init);
                    }
                    else
                    {
                        net.AddArc(gold_prog_str + (j - 1).ToString(), gold_prog_str + j.ToString());
                    }



                //create nodes for Identity and Action and Gold

                        net.AddNode(Network.NodeType.Cpt, GamePhase + j.ToString());
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_1);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_2);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_3);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_4);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_5);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_6);
                        net.AddOutcome(GamePhase + j.ToString(), phase_node_7);
                        net.DeleteOutcome(GamePhase + j.ToString(), 0);
                        net.DeleteOutcome(GamePhase + j.ToString(), 0);
                        net.SetNodePosition(GamePhase + j.ToString(), j * 400, 200, 50, 50);
                        net.SetNodeBgColor(GamePhase + j.ToString(), Color.Aquamarine);
                        if (j == 1)
                        {
                            net.SetNodeDefinition(GamePhase + j.ToString(), day_init);
                        }
                        else
                        {
                            net.AddArc(GamePhase + (j - 1).ToString(), GamePhase + j.ToString());

                            
                        }

                        net.AddNode(Network.NodeType.Cpt, action_str + j.ToString());
                        net.AddOutcome(action_str + j.ToString(), Action_node_4);
                        net.AddOutcome(action_str + j.ToString(), Action_node_3);
                        net.AddOutcome(action_str + j.ToString(), Action_node_2);
                        net.AddOutcome(action_str + j.ToString(), Action_node_1);
                        net.DeleteOutcome(action_str + j.ToString(), 0);
                        net.DeleteOutcome(action_str + j.ToString(), 0);
                        net.SetNodePosition(action_str + j.ToString(), (j) * 500, 100, 50, 50);
                        net.SetNodeBgColor(action_str + j.ToString(), Color.Red);
                        net.AddArc(identity_str, action_str + j.ToString());
                        if (j == 1)
                        {
                            net.SetNodeDefinition(action_str + j.ToString(), action_init);
                        }
                        else
                        {
                          
                            //action->goldn+1
                            net.AddArc(action_str + (j - 1).ToString(), gold_prog_str + j.ToString());
                            //action->wood+1
                            net.AddArc(action_str + (j - 1).ToString(), raft_prog_str + j.ToString());
                            net.AddArc(GamePhase + j.ToString(), action_str + j.ToString());
                            net.AddArc(gold_prog_str + (j).ToString(), action_str + j.ToString());
                            net.AddArc(raft_prog_str + j.ToString(), action_str + j.ToString());
                        }

                        //actionN->WoodN+1
                   
                        if (j > 1)
                        {

                            net.SetNodeDefinition(GamePhase + j.ToString(), day);
                            net.SetNodeDefinition(gold_prog_str + j.ToString(), gold);
                            net.SetNodeDefinition(raft_prog_str + j.ToString(), wood);
                            net.SetNodeDefinition(action_str + j.ToString(), action);
    
                        }
                  
                        net.SetNodePosition(gold_prog_str + j.ToString(), (j) * 500, 400, 50, 50);
                        net.SetNodeBgColor(gold_prog_str + j.ToString(), Color.Yellow);
    
                    }
				//set arcos iniciais
					net.AddArc(raft_prog_str+one,action_str+one);
					net.AddArc(gold_prog_str+one,action_str+one);
					net.AddArc(GamePhase+one,action_str+one);

                    net.WriteFile(network_file_name);
            }
            catch (SmileException e)
            {
                Console.WriteLine(e.Message);
            }

            return net;
        }

         public  Network create_init_network(String init_file_name)
         {
              Network net = new Network();
              try
              {
                  net.AddNode(Network.NodeType.Cpt, GamePhase + init);
                  net.AddOutcome(GamePhase + init, phase_node_1);
                  net.AddOutcome(GamePhase + init, phase_node_2);
                  net.AddOutcome(GamePhase + init, phase_node_3);
                  net.AddOutcome(GamePhase + init, phase_node_4);
                  net.AddOutcome(GamePhase + init, phase_node_5);
                  net.AddOutcome(GamePhase + init, phase_node_6);
                  net.AddOutcome(GamePhase + init, phase_node_7);
                  net.DeleteOutcome(GamePhase + init, 0);
                  net.DeleteOutcome(GamePhase + init, 0);
                  net.SetNodePosition(GamePhase + init, 100, 200, 50, 50);
                  net.SetNodeBgColor(GamePhase +init, Color.Aquamarine);

                  net.AddNode(Network.NodeType.Cpt, identity_str);
                  net.SetOutcomeId(identity_str, 0, "Strong");
                  net.SetOutcomeId(identity_str, 1, "Weak");

                  net.SetNodePosition(identity_str, 550, 20, 50, 50);
                  net.SetNodeBgColor(identity_str, Color.Orange);

                  net.AddNode(Network.NodeType.Cpt, raft_prog_str + init);
                  net.AddOutcome(raft_prog_str + init, Raft_node_1);
                  net.AddOutcome(raft_prog_str + init, Raft_node_2);
                  net.AddOutcome(raft_prog_str + init, Raft_node_3);
                  net.AddOutcome(raft_prog_str + init, Raft_node_4);
                  net.AddOutcome(raft_prog_str + init, Raft_node_5);
                  net.DeleteOutcome(raft_prog_str + init, 0);
                  net.DeleteOutcome(raft_prog_str + init, 0);
                  net.SetNodePosition(raft_prog_str + init, 300, 300, 150, 50);
                  net.SetNodeBgColor(raft_prog_str + init, Color.Green);

                  net.AddNode(Network.NodeType.Cpt, gold_prog_str + init);
                  net.AddOutcome(gold_prog_str + init, Gold_node_1);
                  net.AddOutcome(gold_prog_str + init, Gold_node_2);
                  net.AddOutcome(gold_prog_str + init, Gold_node_3);
                  net.AddOutcome(gold_prog_str + init, Gold_node_4);
                  net.AddOutcome(gold_prog_str + init, Gold_node_5);
                  net.DeleteOutcome(gold_prog_str + init, 0);
                  net.DeleteOutcome(gold_prog_str + init, 0);
                  net.SetNodePosition(gold_prog_str + init, 300, 400, 50, 50);
                  net.SetNodeBgColor(gold_prog_str + init, Color.Yellow);

                  net.AddNode(Network.NodeType.Cpt, action_str + init);
                  net.AddOutcome(action_str + init, Action_node_4);
                  net.AddOutcome(action_str + init, Action_node_3);
                  net.AddOutcome(action_str + init, Action_node_2);
                  net.AddOutcome(action_str + init, Action_node_1);
                  net.DeleteOutcome(action_str + init, 0);
                  net.DeleteOutcome(action_str + init, 0);
                  net.SetNodePosition(action_str + init, 300, 100, 50, 50);
                  net.SetNodeBgColor(action_str + init, Color.Red);

                  double[] GoldDef = { 1.0, 0.0, 0.0, 0, 0 };
                  net.SetNodeDefinition(gold_prog_str + init, GoldDef);

                  double[] WoodDef = { 1.0, 0.0, 0.0, 0, 0 };
                  net.SetNodeDefinition(raft_prog_str + init, WoodDef);

                  net.AddArc(identity_str, action_str + init);

                  net.WriteFile(init_file_name);
              }
              catch (SmileException e)
              {
                  Console.WriteLine(e.Message);
              }
              return net;


         }

         public  Network create_abstract_net(String abstract_network_file_name)
        {
            Network net = new Network();
            try
            {
                net.AddNode(Network.NodeType.Cpt, identity_str);
                net.SetOutcomeId(identity_str, 0, "Strong");
                net.SetOutcomeId(identity_str, 1, "Weak");

                net.SetNodePosition(identity_str, 550, 20, 50, 50);
                net.SetNodeBgColor(identity_str, Color.Orange);

                net.AddNode(Network.NodeType.Cpt, raft_prog_str);
                net.AddOutcome(raft_prog_str, Raft_node_1);
                net.AddOutcome(raft_prog_str, Raft_node_2);
                net.AddOutcome(raft_prog_str, Raft_node_3);
                net.AddOutcome(raft_prog_str, Raft_node_4);
                net.AddOutcome(raft_prog_str, Raft_node_5);
                net.DeleteOutcome(raft_prog_str, 0);
                net.DeleteOutcome(raft_prog_str, 0);
                net.SetNodePosition(raft_prog_str,500, 300, 150, 50);
                net.SetNodeBgColor(raft_prog_str, Color.Green);

                net.AddNode(Network.NodeType.Cpt, GamePhase );
                net.AddOutcome(GamePhase , phase_node_1);
                net.AddOutcome(GamePhase , phase_node_2);
                net.AddOutcome(GamePhase , phase_node_3);
                net.AddOutcome(GamePhase , phase_node_4);
                net.AddOutcome(GamePhase , phase_node_5);
                net.AddOutcome(GamePhase , phase_node_6);
                net.AddOutcome(GamePhase, phase_node_7);
                net.DeleteOutcome(GamePhase , 0);
                net.DeleteOutcome(GamePhase , 0);
                net.SetNodePosition(GamePhase , 400, 200, 50, 50);
                net.SetNodeBgColor(GamePhase , Color.Aquamarine);

                net.AddNode(Network.NodeType.Cpt, GamePhase+one);
                net.AddOutcome(GamePhase + one, phase_node_1);
                net.AddOutcome(GamePhase + one, phase_node_2);
                net.AddOutcome(GamePhase + one, phase_node_3);
                net.AddOutcome(GamePhase + one, phase_node_4);
                net.AddOutcome(GamePhase + one, phase_node_5);
                net.AddOutcome(GamePhase + one, phase_node_6);
                net.AddOutcome(GamePhase + one, phase_node_7);
                net.DeleteOutcome(GamePhase + one, 0);
                net.DeleteOutcome(GamePhase + one, 0);
                net.SetNodePosition(GamePhase + one, 500, 200, 50, 50);
                net.SetNodeBgColor(GamePhase + one, Color.Aquamarine);

                net.AddArc(GamePhase, GamePhase + one);

                net.AddNode(Network.NodeType.Cpt, raft_prog_str+one);
                net.AddOutcome(raft_prog_str + one, Raft_node_1);
                net.AddOutcome(raft_prog_str + one, Raft_node_2);
                net.AddOutcome(raft_prog_str + one, Raft_node_3);
                net.AddOutcome(raft_prog_str + one, Raft_node_4);
                net.AddOutcome(raft_prog_str + one, Raft_node_5);
                net.DeleteOutcome(raft_prog_str + one, 0);
                net.DeleteOutcome(raft_prog_str + one, 0);
                net.SetNodePosition(raft_prog_str+one, 700, 300, 150, 50);
                net.SetNodeBgColor(raft_prog_str+one, Color.Green);


                
                net.AddNode(Network.NodeType.Cpt, gold_prog_str);
                net.AddOutcome(gold_prog_str, Gold_node_1);
                net.AddOutcome(gold_prog_str, Gold_node_2);
                net.AddOutcome(gold_prog_str, Gold_node_3);
                net.AddOutcome(gold_prog_str, Gold_node_4);
                net.AddOutcome(gold_prog_str, Gold_node_5);
                net.DeleteOutcome(gold_prog_str, 0);
                net.DeleteOutcome(gold_prog_str, 0);
                net.SetNodePosition(gold_prog_str,  500, 400, 50, 50);
                net.SetNodeBgColor(gold_prog_str, Color.Yellow);

                net.AddNode(Network.NodeType.Cpt, gold_prog_str + one);
                net.AddOutcome(gold_prog_str + one, Gold_node_1);
                net.AddOutcome(gold_prog_str + one, Gold_node_2);
                net.AddOutcome(gold_prog_str + one, Gold_node_3);
                net.AddOutcome(gold_prog_str + one, Gold_node_4);
                net.AddOutcome(gold_prog_str + one, Gold_node_5);
                net.DeleteOutcome(gold_prog_str + one, 0);
                net.DeleteOutcome(gold_prog_str + one, 0);
                net.SetNodePosition(gold_prog_str+one, 700, 400, 50, 50);
                net.SetNodeBgColor(gold_prog_str+one, Color.Yellow);


                net.AddNode(Network.NodeType.Cpt, action_str);
                net.AddOutcome(action_str, Action_node_4);
                net.AddOutcome(action_str, Action_node_3);
                net.AddOutcome(action_str, Action_node_2);
                net.AddOutcome(action_str, Action_node_1);
                net.DeleteOutcome(action_str, 0);
                net.DeleteOutcome(action_str, 0);
                net.SetNodePosition(action_str, 500, 100, 50, 50);
                net.SetNodeBgColor(action_str, Color.Red);

                

                net.AddNode(Network.NodeType.Cpt, action_str + one);
                net.AddOutcome(action_str + one, Action_node_4);
                net.AddOutcome(action_str + one, Action_node_3);
                net.AddOutcome(action_str + one, Action_node_2);
                net.AddOutcome(action_str + one, Action_node_1);
                net.DeleteOutcome(action_str + one, 0);
                net.DeleteOutcome(action_str + one, 0);
                net.SetNodePosition(action_str + one,  700, 100, 50, 50);
                net.SetNodeBgColor(action_str + one, Color.Red);

                net.AddArc(GamePhase, action_str);
                net.AddArc(GamePhase+one, action_str+one);
                net.AddArc(identity_str, action_str);
                net.AddArc(identity_str, action_str+one);

               
                net.AddArc(raft_prog_str , action_str);
                net.AddArc(raft_prog_str + one, action_str + one);
 
                net.AddArc(raft_prog_str, raft_prog_str+one);



              
                net.AddArc(gold_prog_str, action_str);
                net.AddArc(gold_prog_str + one, action_str + one);
      
                net.AddArc(gold_prog_str, gold_prog_str + one);

                net.AddArc(action_str, raft_prog_str + one);
                net.AddArc(action_str, gold_prog_str + one);
               

  

                net.WriteFile(abstract_network_file_name);
            }
            catch (SmileException e)
            {
                Console.WriteLine(e.Message);
            }
            return net;
        }


         public  void create_data_file_Header(StreamWriter sw)
         {

             string nodes = "";
             nodes = string.Concat(nodes, identity_str + " " + gold_prog_str + " " + raft_prog_str + " " + action_str +" " +GamePhase+" " + gold_prog_str+one + " " + raft_prog_str+one + " " + action_str +one+ " " +GamePhase+one+"\n");
             sw.Write(nodes);

         }

         public  void create_init_data_file_Header(ref StreamWriter sw)
         {
             
             string nodes = "";
             nodes = string.Concat(nodes, identity_str + " " + gold_prog_str + init + " " + raft_prog_str + init + " " + action_str+init + " " + GamePhase+init+"\n");
             sw.Write(nodes);

         }

         public static void create_game_network_Header(StreamWriter sw, int n)
         {
             string nodes = "";
             for (int i = 0; i < n; i++)
             {
                 if(!(i==(n-1)))
                     nodes = string.Concat(nodes, identity_str + " " + gold_prog_str + (i + 1).ToString() + " " + raft_prog_str + (i + 1).ToString() + " " + action_str + (i + 1).ToString() + " " + GamePhase + (i + 1).ToString() + " " + gold_prog_str + (i + 2).ToString() + " " + raft_prog_str + (i + 2).ToString() + " " + action_str + (i + 2).ToString() + " " + GamePhase + (i + 2).ToString()+" ");
                 else{
                     nodes = string.Concat(nodes, identity_str + " " + gold_prog_str + (i + 1).ToString() + " " + raft_prog_str + (i + 1).ToString() + " " + action_str + (i + 1).ToString() + " " + GamePhase + (i + 1).ToString() + " " + gold_prog_str + (i + 2).ToString() + " " + raft_prog_str + (i + 2).ToString() + " " + action_str + (i + 2).ToString() + " " + GamePhase + (i + 2).ToString()+"\n");
                 }

             }
             sw.Write(nodes);
         }

         public  void create_init_data_file(String file,List<List<List<int>>> lista_accoes, int jogadores, int raft_wood, int _gold_pa, int timeactions, int primed)
         {
             StreamWriter sw = new StreamWriter(file, true);
             string nodes = "";
                 for(int i =0;i<jogadores;i++){
                     if (primed == 1)
                    {
                        nodes = string.Concat(nodes, "Strong ");
                    }
                    else
                    {
                        nodes = string.Concat(nodes, "Weak ");
                    }
                     nodes = string.Concat(nodes, Gold_node_1 + " " + Raft_node_1 + " " + action_description(lista_accoes[i][0][6], timeactions) + " " + phase_node_1 + "\n");
                 }
                 sw.Write(nodes);
                 sw.Close();
         }

        public  void create_data_file(String data_file_name,ref List<List<List<int>>> lista_accoes, int jogadores,int teams, int days,int raft_wood,int _gold_pa,int timeactions, int primed)
        {
            string name = data_file_name;
            StreamWriter sw=new StreamWriter(name,true);//not
          
            
         
            for (int j = 0; j < jogadores; j++)
            {
                //comecar no primeiro dia
                for (int i = 1; i <lista_accoes[j].Count ; i++)
                {
                    string aux = null;
                    string priming = null;
                    string init = null;
                    string n = null;
                    string n1 = null;
                    if (primed == 1)
                    {
                        priming = "Strong ";
                        aux = string.Concat(aux, priming);
                    }
                    else
                    {
                        priming = "Weak ";
                        aux = string.Concat(aux, priming);
                    }
                    if (i == 1)
                    {
                        init = string.Concat(init, gold_index(lista_accoes[j][0][2], _gold_pa * timeactions * days) + " ");

                        init = string.Concat(init, raft_progress_index(lista_accoes[j][0][0], raft_wood) + " ");

                        init = string.Concat(init, action_description(lista_accoes[j][0][6], timeactions) + " ");

                        init = string.Concat(init, gamePhaseIndex(i, days) + " ");

                        init = string.Concat(init, gold_index(lista_accoes[j][0][2], _gold_pa * timeactions * days) + " ");

                        init = string.Concat(init, raft_progress_index(lista_accoes[j][0][0], raft_wood) + " ");

                        init = string.Concat(init, action_description(lista_accoes[j][0][6], timeactions) + " ");

                        init = string.Concat(init, gamePhaseIndex(i, days) + " ");

                        aux = string.Concat(aux, init + "\n");
                    }

                    if (!(lista_accoes[j][i][6] == 0 && lista_accoes[j][i][7] == 0))
                    {
                        if (i == 1)
                        {
                            n = string.Concat(n, priming);
                        }
                        n = string.Concat(n, gold_index(lista_accoes[j][i - 1][2], _gold_pa * timeactions * days) + " ");

                        n = string.Concat(n, raft_progress_index(lista_accoes[j][i - 1][0], raft_wood) + " ");

                        n = string.Concat(n, action_description(lista_accoes[j][i - 1][6], timeactions) + " ");

                        n = string.Concat(n, gamePhaseIndex(i, days) + " ");

                        n1 = string.Concat(n1, gold_index(lista_accoes[j][i][2], _gold_pa * timeactions * days) + " ");

                        n1 = string.Concat(n1, raft_progress_index(lista_accoes[j][i][0], raft_wood) + " ");

                        n1 = string.Concat(n1, action_description(lista_accoes[j][i][6], timeactions) + " ");

                        n1 = string.Concat(n1, gamePhaseIndex(i + 1, days) + " ");

                        aux = string.Concat(aux, n + n1 + "\n");

                        sw.Write(aux);
                    }
                    }

                
                }
                
               
            
            
            sw.Close();
          
        }

		 public void writeProbabilityFile(StreamWriter sp, int identityNoutcomes, double[] identityNode, int raftNoutcomes, double[] raftNode, int goldNoutcomes, double[] goldNode, int gamePhaseNoutcomes, double[] gamePhaseNode, int actionNoutcomes, double[] actionNode)
         {
             string node = "";
             node = string.Concat(node, identity_str + identityNoutcomes.ToString() + "\n");
             for (int i = 0; i < identityNode.Length; i++)
             {
                 node = string.Concat(node, identityNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + raft_prog_str + raftNoutcomes.ToString() + "\n");
             for (int i = 0; i < raftNode.Length; i++)
             {
                 node = string.Concat(node, raftNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + gold_prog_str + goldNoutcomes.ToString() + "\n");
             for (int i = 0; i < goldNode.Length; i++)
             {
                 node = string.Concat(node, goldNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + GamePhase + gamePhaseNoutcomes.ToString() + "\n");
             for (int i = 0; i < gamePhaseNode.Length; i++)
             {
                 node = string.Concat(node, gamePhaseNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + action_str + actionNoutcomes.ToString() + "\n");
             for (int i = 0; i < actionNode.Length; i++)
             {
                 node = string.Concat(node,actionNode[i].ToString() + " ");
             }
			node = string.Concat(node,"\n");

             sp.Write(node);


        }
     
        public void writeInitProbabilityFile(StreamWriter sp, int identityNoutcomes, double[] identityNode, int raftNoutcomes, double[] raftNode, int goldNoutcomes, double[] goldNode, int gamePhaseNoutcomes, double[] gamePhaseNode, int actionNoutcomes, double[] actionNode)
         {
             string node = "";
             node = string.Concat(node, identity_str + identityNoutcomes.ToString() + "\n");
             for (int i = 0; i < identityNode.Length; i++)
             {
                 node = string.Concat(node, identityNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + raft_prog_str + raftNoutcomes.ToString() + "\n");
             for (int i = 0; i < raftNode.Length; i++)
             {
                 node = string.Concat(node, raftNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + gold_prog_str + goldNoutcomes.ToString() + "\n");
             for (int i = 0; i < goldNode.Length; i++)
             {
                 node = string.Concat(node, goldNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + GamePhase + gamePhaseNoutcomes.ToString() + "\n");
             for (int i = 0; i < gamePhaseNode.Length; i++)
             {
                 node = string.Concat(node, gamePhaseNode[i].ToString() + " ");
             }
             node = string.Concat(node, "\n" + action_str + actionNoutcomes.ToString() + "\n");
             for (int i = 0; i < actionNode.Length; i++)
             {
                 node = string.Concat(node,actionNode[i].ToString() + " ");
             }
			node = string.Concat(node,"\n");

             sp.Write(node);


        }
		
        }
    
    }

