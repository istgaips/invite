using System;
using System.IO;
using System.Drawing;
using System.Collections.Generic;
using MicrosoftResearch.Infer;
using MicrosoftResearch.Infer.Models;
using System.Text;
using Smile;
using Smile.Learning;
using INVITE.Agents;

namespace INVITE.Agents
{
	public class Parser{
		
		 	const string init_data_file = "init_data_file.txt";
		 	
			const string data_file_name = "data_file.txt";
			const string init_file_name = "init.xdsl";
		    const string abstract_network_file_name = "abstract.xdsl";
			const string nome_log1 = "MATCHLOG_Match_";
        	const string nome_log2 = "_0AllLog.txt";
        	const string log_path = "C:\\Users\\Andre\\Downloads\\";
			const string probability_file = "..\\probabilities.txt";
			const string init_probability_file = "..\\probabilities_init.txt";
        
		
   public static void Main()
        {
            
			LogProcessing LP=new LogProcessing();
            Network net = new Network();
            
          //  net.ReadFile("C:\\Users\\Andre\\Documents\\Visual Studio 2010\\Projects\\log_parser\\log_parser\\Model.xdsl");

   			const int number_of_days = 7;
            List<String> lista_jogadores;
            int count = 0;
            int numberTeams=0;
            int numberHumanPlayers = 0;
            int wood_pa = 0;
            int gold_pa = 0;
            int TimeActions = 0;
            int total_days = 0;
            int days_left = 0;
            int total_raft_wood = 0;
            int primed = 0;
            int n_logs;
            string readl;
			double[] identityInit,raftInit,goldInit,actionInit,gamePhaseInit;
            double[] identityNode, raftNode, goldNode, actionNode, gamePhaseNode;
            int identityNoutcomes, raftNoutcomes,goldNoutcomes,actionNoutcomes,gamePhaseNoutcomes;
			int identityInitNoutcomes, raftInitNoutcomes,goldInitNoutcomes,actionInitNoutcomes,gameInitPhaseNoutcomes;
            DataSet data_set = new DataSet();
            DataSet data_set_init = new DataSet();
            DataMatch[] matches;
            DataMatch[] matches_init;
            Console.WriteLine("Parser started\n");
            Console.WriteLine("Number of Logs to process: \n");
            readl = Console.ReadLine();
            n_logs = Convert.ToInt32(readl);
           
            //TODO : Ler mais que um log (numa mesma directoria?)

            //escrever headers dos ficheiros e apagar se existirem
            if (File.Exists(init_data_file))
            {
                File.Delete(init_data_file);
            }
            StreamWriter sw_init = new StreamWriter(init_data_file, true);
            LP.create_init_data_file_Header(ref sw_init);
            if (File.Exists(data_file_name))
            {
                File.Delete(data_file_name);
            }
            StreamWriter sw_data = new StreamWriter(data_file_name, true);
            LP.create_data_file_Header(sw_data);
            sw_data.Close();
            sw_init.Close();

            //create initial network (5 initial nodes) network structure
			//abstract_net
            Network init_net = LP.create_init_network(init_data_file);
            Network abstract_net = LP.create_abstract_net(abstract_network_file_name);
          //  Network net1 = create_Network1(numberHumanPlayers, days_left);

            /*Percorrer cada log
             *Ass1: "C:\\Users\\Andre\\Downloads\\MATCHLOG_Match_X_0AllLog.txt" estão na mesma pasta e mantêm o mesmo nome
             *  apenas mudando o X
             */
            for(int u=0;u<n_logs;u++){

                StreamReader sr = new StreamReader(log_path+nome_log1+(u+1).ToString()+nome_log2);


                try
                {
                    lista_jogadores = new List<String>();
                //ler parametros de jogo
                if (!LP.get_Params(ref sr, ref count, ref numberTeams,  ref wood_pa, ref gold_pa, ref TimeActions, ref days_left, ref total_raft_wood, ref lista_jogadores,ref primed))
                {
                    Console.WriteLine("Parametros Invalidos\n");
                }
                total_days = days_left;
                numberHumanPlayers = lista_jogadores.Count;


                List<String> jogadores= new List<string>();
         

                List<List<List<int>>> lista_accoes = new List<List<List<int>>>(numberHumanPlayers);
                for (int it = 0; it < numberHumanPlayers; it++)
                {
                lista_accoes.Add(new List<List<int>>());
                }
         
                for (int i = 0; i < lista_jogadores.Count; i++)
                {
                        jogadores.Add(lista_jogadores[i]);
                        Console.WriteLine(lista_jogadores.Count.ToString());
              
                }
  

                //Ler do ficheiro e preencher estrutura

                LP.get_Info(ref sr,ref lista_jogadores ,ref lista_accoes, ref numberHumanPlayers, ref total_raft_wood, ref wood_pa, ref gold_pa);


                LP.create_init_data_file(init_data_file,lista_accoes, numberHumanPlayers, total_raft_wood, gold_pa, TimeActions, primed);
                LP.create_data_file(data_file_name,ref lista_accoes, numberHumanPlayers, numberTeams, total_days,total_raft_wood, gold_pa,TimeActions,primed);
                //  Console.WriteLine("player {0} {1} {2} {3} {4} {5} {6} {7}", lista_accoes[1][1][7], lista_accoes[2][4][1], lista_accoes[2][4][2], lista_accoes[2][4][3], lista_accoes[2][4][4], lista_accoes[2][4][5], lista_accoes[2][4][6], lista_accoes[2][4][7]);
                }
               
                catch (Exception e)
                {
                    Console.WriteLine("The process failed: {0}", e.ToString());
                }

                }
            //depois de ler os logs...
            data_set.ReadFile(data_file_name);
            data_set_init.ReadFile(init_data_file);

            matches = data_set.MatchNetwork(abstract_net);
            matches_init = data_set_init.MatchNetwork(init_net);
            EM em_init = new EM();
            EM em = new EM();
			
			
			

            em.Learn(data_set, abstract_net, matches);
            em.Learn(data_set_init, init_net, matches_init);

			
			//init_net.
            init_net.WriteFile(init_file_name);
			
			identityInit = init_net.GetNodeDefinition(1);
			identityInitNoutcomes=init_net.GetOutcomeCount(1);
            gamePhaseInit=init_net.GetNodeDefinition(0);
			gameInitPhaseNoutcomes=init_net.GetOutcomeCount(0);
            raftInit = init_net.GetNodeDefinition(2);
			raftInitNoutcomes=init_net.GetOutcomeCount(2);
            goldInit = init_net.GetNodeDefinition(3);
			goldInitNoutcomes=init_net.GetOutcomeCount(3);
            actionInit = init_net.GetNodeDefinition(4);
			actionInitNoutcomes=init_net.GetOutcomeCount(4);
			
			double[] IdentityInitProb = identityInit;
            double[] gamePhaseInitProb = gamePhaseInit;
            double[] raftInitProb = raftInit;
            double[] goldInitProb = goldInit;
			
			
			
			
            abstract_net.WriteFile(abstract_network_file_name);
			
			identityNode = abstract_net.GetNodeDefinition(0);
            identityNoutcomes=abstract_net.GetOutcomeCount(0);
            raftNode = abstract_net.GetNodeDefinition(4);
            raftNoutcomes=abstract_net.GetOutcomeCount(4);
            goldNode = abstract_net.GetNodeDefinition(6);
            goldNoutcomes=abstract_net.GetOutcomeCount(6);
            gamePhaseNode = abstract_net.GetNodeDefinition(3);
                                                                                                                                                                                                                                                                  gamePhaseNoutcomes=abstract_net.GetOutcomeCount(3);
            actionNode = abstract_net.GetNodeDefinition(8);
            actionNoutcomes=abstract_net.GetOutcomeCount(8);
			
			 if (File.Exists(probability_file))
            {
                File.Delete(probability_file);
            }
            StreamWriter sp = new StreamWriter(probability_file, true);
			StreamWriter spi = new StreamWriter(init_probability_file,true);
			
			LP.writeInitProbabilityFile (spi,identityInitNoutcomes,IdentityInitProb,raftInitNoutcomes,raftInitProb,goldInitNoutcomes,goldInitProb,gameInitPhaseNoutcomes,gamePhaseInitProb,actionInitNoutcomes,actionInit);
			
            LP.writeProbabilityFile(sp, identityNoutcomes, identityNode, raftNoutcomes, raftNode, goldNoutcomes, goldNode, gamePhaseNoutcomes, gamePhaseNode, actionNoutcomes, actionNode);
            sp.Close();
			spi.Close();
			
            LP.create_Network1(init_file_name,abstract_network_file_name ,number_of_days);
            Console.Read();
  }
}
}