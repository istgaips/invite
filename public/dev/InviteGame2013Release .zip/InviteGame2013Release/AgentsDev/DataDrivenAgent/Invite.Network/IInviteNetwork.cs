using System.Collections.Generic;
using Invite.Network.Constants;

namespace Invite.Network
{
	public interface IInviteNetwork
	{
        /// <summary>
        /// Update beliefs of the bayesian network.
        /// </summary>
        void UpdateBeliefs();

        /// <summary>
        /// Gets the identity node
        /// </summary>
        INode<Identity> IdentityNode { get; }

        /// <summary>
        /// Gets all action nodes grouped by timeslice.
        /// First time slice has key = 1.
        /// </summary>
        IDictionary<int, INode<Action>> ActionNodes { get; }

        /// <summary>
        /// Gets all raft progression nodes grouped by timeslice.
        /// </summary>
        IDictionary<int, INode<RaftProgression>> RaftProgressionNodes { get; }

        /// <summary>
        /// Gets all Gold collected nodes grouped by timeslice.
        /// First time slice has key = 1.
        /// </summary>
  		IDictionary<int, INode<GoldCollected>> GoldCollectedNodes { get; }

        /// <summary>
        /// Gets all game phase nodes grouped by timeslice.
        /// First time slice has key = 1.
        /// </summary>
        IDictionary<int, INode<GamePhase>> GamePhaseNodes { get; }
	}
}

