
namespace Invite.Network.Constants
{
    /// <summary>
        /// Amount of time spent gathering wood.
        /// DefectBarely, spents most of the time gathering wood.
        /// </summary>             
	public enum Action : int
    {
        VeryStronglyDefect, StronglyDefect, Defect, DefectBarely  
    }

	public enum GamePhase : int
    {
        Beginning, VeryEarly, Early, HalfWay, Late, VeryLate, End
    }

    public enum GoldCollected : int
    {
        VeryFew, Few, HalfWay, High, VeryHigh
    }

	public enum Identity : int
    {
       Strong, Weak
    }
	
	public enum RaftProgression : int
    {
		VeryFew, Few, HalfWay, High, VeryHigh
    }
}