
namespace Invite.Network
{
	public interface INode<T>
	{		
		/*
        public double[] Definition
        {
            get { return this.SmileNetwork.GetNodeDefinition(this.Handle); }
            set { this.SmileNetwork.SetNodeDefinition(this.Handle, value); }
        }
        */

        /// <summary>
        /// Gets the probability distribution over the possible outcomes of this node.
        /// </summary>
        double[] Value { get; }
		
		void SetEvidence(T value);
		
		T MostLikelyOutcome { get; }
		
		T Sample();

	}
}

