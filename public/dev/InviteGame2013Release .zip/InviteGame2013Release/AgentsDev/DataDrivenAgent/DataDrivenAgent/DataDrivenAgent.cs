using System;
using System.Linq;
using System.IO;
//using System.Threading;
//using System.Configuration;


using INVITE;
using Invite.Network;
using Invite.Network.Constants;
using Invite.Network.InferNet;

using ActionOutcome = Invite.Network.Constants.Action;

using ION.Agents;


namespace INVITE.Agents
{
	public class DataDrivenAgent : Player
	{	
        public enum Policy : int
        {
            Random, MaximumLikelyhood
        }
	
		private uint minDelay = 0;
		private uint maxDelay = 10;
		private bool isMoving;
        private IInviteNetwork network;
		private string probability_file = "\\Agents\\probabilities.txt";
		private string init_probability_file="..\\AgentsDev\\DataDrivenAgent\\LogProcessing\\bin\\probabilities_init.txt";
   
		public DataDrivenAgent(string myid, string name, string mytype, ITeam team, uint playerTimePerDay)
			: base (myid, name, mytype, team, playerTimePerDay)
		{
			//TODO PREENCHER ESTES VALORES DO FICHEIRO
			//double[] actionAPriori = null; // this is currently not used, first action depends on identity, etc...
			double[,,,][] actionCPT = null; 
			double[,][] goldCollectedCPT = null;
			double[,][] raftProgressionCPT = null;
			double[][] gamePhaseCPT = null;
			double[] identityCPT=null; 
			double[] action_prob_vector=null,raft_prob_vector=null,gold_prob_vector=null,identity_prob_vector=null,phase_prob_vector=null;
			double[] action_init_prob_vector=null,raft_init_prob_vector=null,gold_init_prob_vector=null,identity_init_prob_vector=null,phase_init_prob_vector=null;
	       
			int identityN=0, gamePhaseN=0, raftN=0, goldN=0, actionN = 0 ;
			int identityInitN=0, gamePhaseInitN=0, raftInitN=0, goldInitN=0, actionInitN = 0 ;
			
			
			uint numberOfDays = Game.Instance.MaximumPlayableDays;
			var primmedIdentity = this.GetGameConfiguredIdentity(Game.Instance);
			
			probability_file = Directory.GetCurrentDirectory() + probability_file;
			StreamReader spr = new StreamReader(probability_file);
			//StreamReader spi = new StreamReader(init_probability_file);
			LearntData ld= new LearntData();
			
			ld.readProbabilityFile(spr, ref action_prob_vector, ref raft_prob_vector, ref gold_prob_vector, ref identity_prob_vector, ref phase_prob_vector,ref identityN, ref gamePhaseN,ref raftN,ref goldN, ref actionN);
			//ld.readProbabilityFile(spi,ref action_init_prob_vector, ref raft_init_prob_vector,ref gold_init_prob_vector,ref identity_init_prob_vector,ref phase_init_prob_vector,ref identityInitN,ref gamePhaseInitN,ref raftInitN,ref goldInitN,ref actionInitN);
			
			actionCPT=ld.actionProbabilities(identityN, gamePhaseN, raftN, goldN,actionN,action_prob_vector);
			raftProgressionCPT=ld.raftProbabilities(raftN, actionN, raft_prob_vector);
			goldCollectedCPT=ld.goldProbabilities(goldN, actionN, gold_prob_vector);
			gamePhaseCPT=ld.gamePhaseProbabilities(gamePhaseN, phase_prob_vector);
			identityCPT=ld.identityProbabilites(identity_prob_vector);
			//actionAPriori=ld.actionInitProbabilites(identityInitN,actionInitN,action_init_prob_vector);
			//  Console.WriteLine("oi" + actionCPT[1, 6, 4, 3][0].ToString() + " " + actionCPT[1, 6, 4, 3][1].ToString() + " " + actionCPT[1, 6, 4, 3][2].ToString() + " " + actionCPT[1, 6, 4, 3][3].ToString());
           // Console.WriteLine("raft" + raftProgressionCPT[0, 0][0].ToString() + " " + raftProgressionCPT[0, 0][1].ToString() + " " + raftProgressionCPT[0, 0][2].ToString() + " " + raftProgressionCPT[0, 0][3].ToString() + " " + raftProgressionCPT[0, 0][4].ToString());
           // Console.WriteLine("game" + gamePhaseCPT[1][0].ToString() + " " + ggamePhaseCPT[1][1].ToString());
			
            this.network = new InviteNetwork(numberOfDays, primmedIdentity //, actionAPriori
											 , actionCPT, goldCollectedCPT
											 , raftProgressionCPT, gamePhaseCPT);
			            

			this.isMoving = false;
			this.Mover.Started += this.OnMoveStarted;
			this.Mover.Stopped += this.OnMoveStopped;
		
			//The following two callbacks serve the same purpose, but sometimes one doesn't work, we I put both in there
			//to have a better guarantee my agent will indeed be warned that he has collected the resourcs.
			this.TimeLeftToday.ValueChanged += this.HoursValueChanged;	
			this.MiniGamePlayer.Stopped += this.OnMiniGameStopped;
		}
		
        private Identity GetGameConfiguredIdentity(Game game)
        {
			return (Identity) Enum.Parse(typeof(Identity), game.GameConfiguration.PrimingType);
        }

		/// <summary>
		/// Updates the evidence in the bayesian network
		/// </summary>
		private void UpdateEvidence()
		{
			var currentDay = Island.Instance.CurrentDay;
				
			this.SetGamePhaseEvidence(currentDay);

			var buildRaftTask = this.Team.BuildRaftTask;
			float raftProgression = buildRaftTask.WoodGathered / buildRaftTask.WoodForCompletion;
			this.SetRaftProgressionEvidence(raftProgression, currentDay);
			
			this.SetCollectedGoldEvidence(this.GoldCollected.Value, currentDay);
			
			//TODO: update evidence regarding own action in last day.
		}

		private void SetGamePhaseEvidence(uint currentDay)
		{
            var evidence = GetOutcomeFromPercentage<GamePhase>((currentDay-1)/Game.Instance.MaximumPlayableDays);
            this.network.GamePhaseNodes[(int)currentDay].SetEvidence(evidence);
		}

		private void SetRaftProgressionEvidence(float raftProgression, uint day)
		{   
            var evidence = GetOutcomeFromPercentage<RaftProgression>(raftProgression);
            this.network.RaftProgressionNodes[(int)day].SetEvidence(evidence);
		}
		
		private void SetCollectedGoldEvidence(float percentageOfMaxGold, uint day)
		{
            var evidence = GetOutcomeFromPercentage<GoldCollected>(percentageOfMaxGold);
            this.network.GoldCollectedNodes[(int)day].SetEvidence(evidence);
        }

        private static T GetOutcomeFromPercentage<T>(float percentage)
        {
            if(!(typeof(T).IsEnum))
            {
                throw new ArgumentException(typeof(T).Name + " must be an Enum.");
            }

            if(percentage < 0 || percentage > 1)
            {
                throw new ArgumentOutOfRangeException("percentage", "parameter percentage must be between 0 and 1.");
            }

            var possibleOutcomes = Enum.GetValues(typeof(T));
			Type typeOfT = typeof(T);
			int value = (int) Math.Floor(percentage * possibleOutcomes.Length);
            //T outcome = (T) Enum.ToObject(typeOfT, value);
            T outcome = (T) possibleOutcomes.GetValue(value);
            return outcome;
        }
		
		public void OnMoveStarted(ION.Agents.IStartedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt)
		{
			this.isMoving = true;
			this.Mover.Pause();
			//Console.WriteLine("Agente " + this.Name + " started moving_aknowledgement");
		}
		
		public void OnMoveStopped(ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) 
		{
			//Console.WriteLine("Agente " + this.Name + " stopped moving_aknowledgement");
			this.isMoving = false;
			this.DecideAction();
		}
		
		protected void OnMiniGameStopped (IStoppedEvent<IMultipleStepEffector<MiniGame>> evt)
		{
			//Console.WriteLine("Agente " + this.Name + " played a minigame");
			if (!this.isMoving)
			{
				this.DecideAction();
			}			
		}
		
		public void HoursValueChanged (ION.Agents.IValueChangedEvent<uint> evt)
		{
			//Console.WriteLine("Agente " + this.Name + " had his hours changed to " + evt.Property.Value);
			if (!this.isMoving)
			{
				this.DecideAction();
			}
		}

		private void DecideAction()
		{
			if(this.TimeLeftToday.Value > 0) // Agent has time to gather resources
			{
				if(this.Locale.Value is IResourceSite) // Agent at resource site. Gather resources
				{
					this.PlayRandomMiniGame();
				}
				else // Move to resource site
				{
					//Console.WriteLine("Agente " + this.Name + " moving to resourceSite");
					this.Mover.Start(new MoveTo(InviteRandom.Instance.RandomResourceSite));
				} 
			}
			else if (this.Locale.Value != this.Team.CampSite) // No more time left and not at camp site. Go to camp site 
			{
				//Console.WriteLine("Agente " + this.Name + " moving to campSite");
				this.Mover.Start(new MoveTo(this.Team.CampSite));
			}
		}
		
		public void PlayRandomMiniGame ()
		{
			// Update bayes network with new information.
			this.UpdateEvidence();

            var currentActionNode = this.network.ActionNodes[(int)Island.Instance.CurrentDay];
            
            var chosenAction = currentActionNode.MostLikelyOutcome; // choose most likely outcome a human player would do
						
            uint timeSpentGatheringWood = this.GetTimeGatheringWood(chosenAction);
            uint timeSpentGatheringGold = this.TimeLeftToday.Value - timeSpentGatheringWood;

            uint delay = InviteRandom.Instance.RandomBetween(this.minDelay, this.maxDelay);
			//Console.WriteLine("Agente " + this.Name + " playing with wood " + wood + " and gold " + gold + " and delay " + delay);
			this.MiniGamePlayer.Start(new MiniGame(timeSpentGatheringWood, timeSpentGatheringGold, delay));
		}


        private uint GetTimeGatheringWood(ActionOutcome action)
        {
            int numberOfPossibleOutcomes = Enum.GetValues(typeof(ActionOutcome)).Length;
            uint timeIntervalLength =(uint) (Game.Instance.PlayerTimePerDay / numberOfPossibleOutcomes); // the time is divided into equal parts
            
            uint actionIdx = (uint) action;
            uint minTime = (uint) (actionIdx * timeIntervalLength);
            uint maxTime = (uint) ((actionIdx+1) * timeIntervalLength);

            return InviteRandom.Instance.RandomBetween(minTime, maxTime);
        }
	}
}

