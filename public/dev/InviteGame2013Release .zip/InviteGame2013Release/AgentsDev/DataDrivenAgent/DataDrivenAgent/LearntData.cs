using System;
using INVITE;
using ION.Agents;
using System.Linq;
using System.Threading;
using System.Configuration;
using System.Collections.Generic;
using System.IO;


namespace INVITE.Agents
{
	public class LearntData
	{
		private const string identity_str = "Identity";
		const string raft_prog_str = "RaftProgression_";
        const string gold_prog_str = "GoldCollected_";
		const string GamePhase = "Phase_";
		const string action_str = "Action_";
		
		public LearntData ()
		{
			
		}
		
		public void readProbabilityFile(StreamReader s, ref double[] action_prob_vector, ref double[]raft_prob_vector, ref double[]gold_prob_vector, ref double[]identity_prob_vector, ref double[]phase_prob_vector, ref int identityN, ref int gamePhaseN,ref int raftN,ref int goldN, ref int actionN)
	    {
		
	        string line = "";
	       
	        while ((line = s.ReadLine()) != null)
	        {
	            if (line.Contains(identity_str))
	            {
	                string ident=line.Substring(identity_str.Length);
	                identityN=Convert.ToInt32(ident);
	                if ((line = s.ReadLine()) != null)
	                {
	                    string[] idProbs = line.Split(' ');
	
	                 //   Console.WriteLine("id "+idProbs.Length.ToString());
	                    identity_prob_vector = new double[idProbs.Length-1];
	
	                    int i=0;
	                   // Console.WriteLine("id " + idProbs.Length.ToString());
	                    foreach (string v in idProbs)
	                    {
	                        if (i<idProbs.Length-1)
	                        {
								string converted = v.Replace(",",".");
				
	                            identity_prob_vector[i] = Convert.ToDouble(converted);
	                          
	                            i++;
	                        }
	                    }
	                }
	            }
	            else if (line.Contains(raft_prog_str))
	            {
	                string raftline = line.Substring(raft_prog_str.Length);
	                raftN = Convert.ToInt32(raftline);
						
	                if ((line = s.ReadLine()) != null)
	                {
	
	                    string[] raftProbs = line.Split(' ');
	                    raft_prob_vector = new double[raftProbs.Length-1];
	
	                    int i = 0;
	                    foreach (string v in raftProbs)
	                    {
	                        if(i<raftProbs.Length-1){
	                        string converted = v.Replace(",",".");
				
	                        raft_prob_vector[i] = Convert.ToDouble(converted);
	                        i++;
	                        }
	                    }
	                }
	            }
	            else if (line.Contains(gold_prog_str))
	            {
	                string goldline = line.Substring(gold_prog_str.Length);
	                goldN = Convert.ToInt32(goldline);
	                if ((line = s.ReadLine()) != null)
	                {
	                    string[] goldProbs = line.Split(' ');
	                    gold_prob_vector = new double[goldProbs.Length-1];
	
	                    int i = 0;
	                    foreach (string v in goldProbs)
	                    {
	                          if(i<goldProbs.Length-1){
	                        string converted = v.Replace(",",".");
				
	                        gold_prob_vector[i] = Convert.ToDouble(converted);
	                        i++;
	                        }
	                    }
	                }
	            }
	            else if (line.Contains(GamePhase))
	            {
	                string gpline = line.Substring(GamePhase.Length);
	                gamePhaseN = Convert.ToInt32(gpline);
	                if ((line = s.ReadLine()) != null)
	                {
	                    string[] gpProbs = line.Split(' ');
	                    phase_prob_vector = new double[gpProbs.Length-1];
	
	                    int i = 0;
	                    foreach (string v in gpProbs)
	                    {
	                        if(i<gpProbs.Length-1){
	                        string converted = v.Replace(",",".");
				
	                        phase_prob_vector[i] = Convert.ToDouble(converted);
	                        i++;
	                        }
	                    }
	                }
	            }
	            else if (line.Contains(action_str))
	            {
	                string actionline = line.Substring(action_str.Length);
	                actionN = Convert.ToInt32(actionline);
				
	                if ((line = s.ReadLine()) != null)
	                {
	                    string[] actionProbs = line.Split(' ');
	                    action_prob_vector = new double[actionProbs.Length-1];
	
	                    int i = 0;
	                    foreach (string v in actionProbs)
	                    {
						
	                        if (i<actionProbs.Length-1)
	                        {
							
								string converted = v.Replace(",",".");
				
	                            action_prob_vector[i] = Convert.ToDouble(converted);
								
							//	Console.WriteLine("u  "+ action_prob_vector[i].ToString());
	                            i++;
	                        }
	                    }
	                }
	            }
	        }
	    }
	
			
	    public  double[, , ,][] actionProbabilities(int _identityNoutcomes, int _gamePhaseNoutcomes, int _raftNoutcomes, int _goldNoutcomes, int _actionNoutcomes, double[] _actionNode)
	    {
	        double[, , ,][] actionProbs = new double[_identityNoutcomes, _gamePhaseNoutcomes, _raftNoutcomes, _goldNoutcomes][];
	        int actionCounter = 0;
	        for (int i = 0; i < _identityNoutcomes; i++)
	        {
	            for (int j = 0; j < _gamePhaseNoutcomes; j++)
	            {
	                for (int k = 0; k < _raftNoutcomes; k++)
	                {
	                    for (int l = 0; l < _goldNoutcomes; l++)
	                    {
	                        actionProbs[i, j, k, l] = new double[_actionNoutcomes];
	                        for (int h = 0; h < _actionNoutcomes && actionCounter < _actionNode.Length; actionCounter++, h++)
	                        {
	                            actionProbs[i, j, k, l][h] = _actionNode[actionCounter];
								//Console.WriteLine("vaiP"+actionProbs[i, j, k, l][h].ToString());
	                        }
	                    }
	
	                }
	
	            }
	
	        }
	        return actionProbs;
	
	    }
	
	    public  double[,][] raftProbabilities(int _raftNoutcomes, int _actionNoutcomes, double[] _raftNode)
	    {
	        double[,][] _raftProbs = new double[_raftNoutcomes, _actionNoutcomes][];
	        int raftNodeCounter=0;
	        for (int i = 0; i < _raftNoutcomes; i++)
	        {
	            for (int j = 0; j < _actionNoutcomes ; j++)
	            {
	                _raftProbs[i, j] = new double[_raftNoutcomes];
	                for(int k=0;k<_raftNoutcomes && raftNodeCounter<_raftNode.Length;raftNodeCounter++,k++){
	                _raftProbs[i,j][k]=_raftNode[raftNodeCounter];
	                Console.WriteLine(_raftProbs[i,j][k].ToString());
					}
	            }
	
	        }
	
	        return _raftProbs;
	    }
	   
	    public double[,][] goldProbabilities(int _goldNoutcomes, int _actionNoutcomes, double[] _goldNode)
	    {
	        double[,][] _goldProbs = new double[_goldNoutcomes, _actionNoutcomes][];
	        int goldNodeCounter=0;
	        for (int i = 0; i < _goldNoutcomes; i++)
	        {
	            for (int j = 0; j < _actionNoutcomes ; j++)
	            {
	                _goldProbs[i, j] = new double[_goldNoutcomes];
	                for(int k=0;k<_goldNoutcomes && goldNodeCounter<_goldNode.Length;goldNodeCounter++,k++)
	                _goldProbs[i,j][k]=_goldNode[goldNodeCounter];
	                
	            }
	
	        }
	
	        return _goldProbs;
	    }
	
	    public  double[][] gamePhaseProbabilities(int _gamePhaseNoutcomes, double[] _gamePhaseNode)
	     {
	         double[][] gamePhaseProbs = new double[_gamePhaseNoutcomes][];
	         int gamePhaseCounter = 0;
	         for(int i=0;i<_gamePhaseNoutcomes;i++){
	             gamePhaseProbs[i]=new double[_gamePhaseNoutcomes];
	             for (int j = 0; j < _gamePhaseNoutcomes && gamePhaseCounter < _gamePhaseNode.Length; j++, gamePhaseCounter++)
	             {
	                 gamePhaseProbs[i][j] = _gamePhaseNode[gamePhaseCounter];
	             }
	
	         }
	         return gamePhaseProbs;
	     }
	
	    public  double[] identityProbabilites( double[] _identityNode)
	     {
	         double[] iProb=_identityNode;
	
	         return iProb;
	     }
	
	    public  double[][] actionInitProbabilites(int _identityNoutcomes,int _actionNoutcomes, double[] actionInitNode)
		{
			int actionInitCount = 0;
			double[][] action=new double[_identityNoutcomes][];
			for (int i = 0; i < _identityNoutcomes ; i++)
			{
				action[i] = new double[_actionNoutcomes];
				for (int j = 0; j < _actionNoutcomes && actionInitCount < actionInitNode.Length; j++, actionInitCount++)
				{
					action[i][j] = actionInitNode[actionInitCount];
				}
			}
			return action;
		}
	}
}


