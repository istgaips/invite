using System;

namespace InferNetTest
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			var actionLen = aux.LengthOf<ActionOutcome>();
			var identityLen = aux.LengthOf<Identity>();
			var phaseLen = aux.LengthOf<GamePhase>();
			var raftLen = aux.LengthOf<RaftProgression>();
			var goldLen = aux.LengthOf<GoldCollected>();		
			
			var actionAPriori = aux.GenerateRandomDistribution(actionLen, 2);
			var actionCPT = aux.GenerateRandomCPTDouble(identityLen, phaseLen, raftLen, goldLen, actionLen);
			var goldCPT = aux.GenerateRandomCPTDouble(goldLen, actionLen, goldLen);
			var raftCPT = aux.GenerateRandomCPTDouble(raftLen, actionLen, raftLen);
			var phaseCPT = aux.GenerateRandomCPTDouble(phaseLen, phaseLen);
					
			var inviteNet = new InviteNetwork(5, Identity.Weak, actionAPriori, actionCPT, goldCPT, raftCPT, phaseCPT);
		}
	}
}
