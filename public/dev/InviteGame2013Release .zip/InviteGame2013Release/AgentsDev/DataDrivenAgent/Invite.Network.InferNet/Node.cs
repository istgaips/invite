using System;
using System.Collections.Generic;

using Invite.Network;

using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer.Distributions;
using MicrosoftResearch.Infer.Maths;


namespace Invite.Network.InferNet
{
	using VarVectArr  = VariableArray<Vector>;
	using VarVectArr2 = VariableArray<VariableArray<Vector>, Vector[][]>;
	using VarVectArr3 = VariableArray<VariableArray<VariableArray<Vector>, Vector[][]>, Vector[][][]>;
	using VarVectArr4 = VariableArray<VariableArray<VariableArray<VariableArray<Vector>, Vector[][]>, Vector[][][]>, Vector[][][][]>;
	
	public abstract class Node
	{
		protected Node(InviteNetwork network)
		{
			this.InferNetNetwork = network;
		}
		internal InviteNetwork InferNetNetwork {get; set;}
		internal Variable<int> InferNetNode { get; set; }
	}
	
	public class Node<T> : Node, INode<T>
	{
		
		#region constructors
		protected Node(InviteNetwork network)
			: base(network)
		{
			if(!typeof(T).IsEnum)
			{
				throw new ArgumentException(typeof(T).FullName.ToString() + " is not an Enum.", "T");
			}
		}
		
		public Node(InviteNetwork network, Range range, double[] aPrioriProbabilities)
			: this(network)
		{
			if(aPrioriProbabilities.Length != InferNetAux.LengthOf<T>())
			{
				throw new ArgumentException("aPrioriProbabilities size not the same as number of elements in " + typeof(T),"aPrioriProbabilities"); 
			}
			
			this.InferNetNode = Variable.Discrete(range, Vector.FromArray(aPrioriProbabilities));
		}
		
		public Node(InviteNetwork network, Range range, T observedValue)
			: this(network)
		{
			this.InferNetNode = Variable.DiscreteUniform(range);
			this.InferNetNode.ObservedValue = (int) ((object)observedValue);			
		}
		
		#region from array cpt
		public Node(InviteNetwork network, Range range, Node parent, double[][] cpt)
			: this(network)
		{
			var parentVar = parent.InferNetNode;
			var parentRange = parentVar.GetValueRange(); 
			var varCPT = InferNetAux.GetCPT(parentRange, cpt);
			
			this.InferNetNode = InferNetAux.VariableDiscrete( range, parentVar, varCPT);
		}
		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2, double[,][] cpt)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			
			var varCPT = InferNetAux.GetCPT(parent1Range, parent2Range, cpt);
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var, varCPT);
		}
		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2, Node parent3,
					double[,,][] cpt)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			var parent3Var = parent3.InferNetNode;
			var parent3Range = parent3Var.GetValueRange(); 

			var varCPT = InferNetAux.GetCPT(parent1Range, parent2Range,
											parent3Range, cpt);
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var,
															 parent3Var, 
															 varCPT);
		}

		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2,
					Node parent3, Node parent4,
					double[,,,][] cpt)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			var parent3Var = parent3.InferNetNode;
			var parent3Range = parent3Var.GetValueRange(); 
			var parent4Var = parent4.InferNetNode;
			var parent4Range = parent4Var.GetValueRange(); 

			
			var varCPT = InferNetAux.GetCPT(parent1Range, parent2Range,
											parent3Range, parent4Range, cpt);
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var,
															 parent3Var, parent4Var,
															 varCPT);
		}
		#endregion
		
		#region from variable array cpt
		public Node(InviteNetwork network, Range range, Node parent, VarVectArr varCPT)
			: this(network)
		{
			var parentVar = parent.InferNetNode;
			var parentRange = parentVar.GetValueRange(); 
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parentVar, varCPT);
		}
		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2, VarVectArr2 varCPT)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var, varCPT);
		}
		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2, Node parent3,
					VarVectArr3 varCPT)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			var parent3Var = parent3.InferNetNode;
			var parent3Range = parent3Var.GetValueRange(); 
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var,
															 parent3Var, 
															 varCPT);
		}

		
		public Node(InviteNetwork network, Range range, Node parent1, Node parent2,
					Node parent3, Node parent4,
					VarVectArr4 varCPT)
			: this(network)
		{
			var parent1Var = parent1.InferNetNode;
			var parent1Range = parent1Var.GetValueRange(); 
			var parent2Var = parent2.InferNetNode;
			var parent2Range = parent2Var.GetValueRange(); 
			var parent3Var = parent3.InferNetNode;
			var parent3Range = parent3Var.GetValueRange(); 
			var parent4Var = parent4.InferNetNode;
			var parent4Range = parent4Var.GetValueRange(); 
			
			this.InferNetNode = InferNetAux.VariableDiscrete(range, parent1Var, parent2Var,
															 parent3Var, parent4Var,
															 varCPT);
		}
		#endregion
		
		#endregion
		
				
		public double[] Value
		{ 
			get 
			{
				var posterior = this.InferNetNetwork.Engine.Infer<Discrete>(this.InferNetNode);
				return posterior.GetProbs().ToArray();
			}
		}
		
		public void SetEvidence(T value)
		{ 
			this.InferNetNode.ObservedValue = (int) ((object)value);
		}
		
		public T MostLikelyOutcome
		{ 
			get
			{
				var possibleOutcomes = Enum.GetValues(typeof(T));
				Type typeOfT = typeof(T);
				int value = this.Value.MaxIndex();
				return (T) possibleOutcomes.GetValue(value);
			}
		}
		
		public T Sample()
		{
			var posterior = this.InferNetNetwork.Engine.Infer<Discrete>(this.InferNetNode);
			int sampledValue = posterior.Sample();
			return (T) Enum.ToObject(typeof(T), sampledValue);
		}
		
	}
}

