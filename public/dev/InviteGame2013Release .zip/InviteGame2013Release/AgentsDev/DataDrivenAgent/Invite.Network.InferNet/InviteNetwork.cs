using System;
using System.Collections.Generic;

using Invite.Network.Constants;
using ActionOutcome = Invite.Network.Constants.Action;

using MicrosoftResearch.Infer;
using MicrosoftResearch.Infer.Models;

namespace Invite.Network.InferNet
{
	public class InviteNetwork : IInviteNetwork
	{
		internal InferenceEngine Engine { get; set;}
		
		internal readonly Range IdentityRange; 
		internal readonly Range ActionRange;
		internal readonly Range GoldCollectedRange;
		internal readonly Range GamePhaseRange;
		internal readonly Range RaftProgressionRange;

		
		public InviteNetwork (
			uint totalOfDays,
			Identity primedIdentity,
			//double[] actionAPriori, // This is currently not used... First action depends on identity etc...
			double[,,,][] actionCPT, 		//_[ identityNoutcomes, _gamePhaseNoutcomes, _raftNoutcomes, _goldNoutcomes ]
			double[,][] goldCollectedCPT,	// [_goldNoutcomes, _actionNoutcomes]
			double[,][] raftProgressionCPT,	// [_raftNoutcomes, _actionNoutcomes ]
			double[][] gamePhaseCPT)		// [_gamePhaseNoutcomes]
		{
			//init ranges
			var identityLen = InferNetAux.LengthOf<Identity>();
			this.IdentityRange = new Range(identityLen).Named("IdentityRange");
			this.ActionRange = new Range(InferNetAux.LengthOf<ActionOutcome>()).Named("ActionRange");
			this.GoldCollectedRange = new Range(InferNetAux.LengthOf<GoldCollected>()).Named("GoldCollectedRange");
			this.GamePhaseRange = new Range(InferNetAux.LengthOf<GamePhase>()).Named("GamePhaseRange");
			this.RaftProgressionRange = new Range(InferNetAux.LengthOf<RaftProgression>()).Named("RaftProgressionRange");
		
			
			//init time slices
			this.ActionNodes = new Dictionary<int, INode<ActionOutcome>>();
			this.RaftProgressionNodes = new Dictionary<int, INode<RaftProgression>>();
			this.GoldCollectedNodes = new Dictionary<int, INode<GoldCollected>>();
			this.GamePhaseNodes = new Dictionary<int, INode<GamePhase>>();
			
			//create nodes
			this.IdentityNode = new Node<Identity>(this, this.IdentityRange, primedIdentity);			
			this.InitDayOne(actionCPT);
			for(int day = 2; day <= totalOfDays; day++)
			{
				this.CreateTimeSliceNodes(day, actionCPT, goldCollectedCPT, raftProgressionCPT, gamePhaseCPT);
			}
			
			
			this.Engine = new InferenceEngine();
			
			//this.Engine.ShowFactorGraph = true;			
		}
		
		private void InitDayOne(
			double[,,,][] actionCPT) //_[ identityNoutcomes, _gamePhaseNoutcomes, _raftNoutcomes, _goldNoutcomes ] 
		{
			
			var raftNode = new Node<RaftProgression>(this, this.RaftProgressionRange, RaftProgression.Few);
			var goldNode = new Node<GoldCollected>(this, this.GoldCollectedRange, GoldCollected.Few);
			var phaseNode = new Node<GamePhase>(this, this.GamePhaseRange, GamePhase.Beginning);
			
			this.RaftProgressionNodes[1] = raftNode;
			this.GoldCollectedNodes[1] = goldNode;
			this.GamePhaseNodes[1] = phaseNode;
			this.ActionNodes[1] = 
				new Node<ActionOutcome>(this, this.ActionRange, this.IdentityNode as Node<Identity>, phaseNode,
								 raftNode, goldNode,
								 actionCPT);
		}
		
		private void CreateTimeSliceNodes(
			int day,
			double[,,,][] actionCPT, 		//_[ identityNoutcomes, _gamePhaseNoutcomes, _raftNoutcomes, _goldNoutcomes ]
			double[,][] goldCollectedCPT,	// [_goldNoutcomes, _actionNoutcomes]
			double[,][] raftProgressionCPT,	// [_raftNoutcomes, _actionNoutcomes ]
			double[][] gamePhaseCPT)		// [_gamePhaseNoutcomes]
		{
			var previousDay = day-1;
			var prevRaft = this.RaftProgressionNodes[previousDay] as Node<RaftProgression>;
			var prevGold = this.GoldCollectedNodes[previousDay] as Node<GoldCollected>;
			var prevPhase = this.GamePhaseNodes[previousDay] as Node<GamePhase>;
			var prevAction = this.ActionNodes[previousDay] as Node<ActionOutcome>;
						
			this.RaftProgressionNodes[day] = 
				new Node<RaftProgression>(this, this.RaftProgressionRange, prevRaft, prevAction, raftProgressionCPT);
			this.GoldCollectedNodes[day] = 
				new Node<GoldCollected>(this, this.GoldCollectedRange, prevGold, prevAction, goldCollectedCPT);
			this.GamePhaseNodes[day] = 
				new Node<GamePhase>(this, this.GamePhaseRange, prevPhase, gamePhaseCPT);
			this.ActionNodes[day] = 
				new Node<ActionOutcome>(this, this.ActionRange, this.IdentityNode as Node<Identity>,
								prevPhase, prevRaft, prevGold,
								 actionCPT);			
		}

		#region IInviteNetwork implementation
		public void UpdateBeliefs ()
		{
			//Not needed
			//throw new NotImplementedException ();
		}

		public INode<Identity> IdentityNode { get; private set; } 

		public IDictionary<int, INode<ActionOutcome>> ActionNodes { get; private set; }

		public IDictionary<int, INode<RaftProgression>> RaftProgressionNodes { get; private set; }

		public IDictionary<int, INode<GoldCollected>> GoldCollectedNodes { get; private set; }

		public IDictionary<int, INode<GamePhase>> GamePhaseNodes { get; private set; }
		#endregion
	}
}

