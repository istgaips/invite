using System;
using System.Linq;

using Invite.Network;
using Invite.Network.Constants;
using ActionOutcome = Invite.Network.Constants.Action;

using MicrosoftResearch.Infer;
using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer.Maths;

namespace Invite.Network.InferNet
{
	using VarVectArr  = VariableArray<Vector>;
	using VarVectArr2 = VariableArray<VariableArray<Vector>, Vector[][]>;
	using VarVectArr3 = VariableArray<VariableArray<VariableArray<Vector>, Vector[][]>, Vector[][][]>;
	using VarVectArr4 = VariableArray<VariableArray<VariableArray<VariableArray<Vector>, Vector[][]>, Vector[][][]>, Vector[][][][]>;
	using VarVectArr5 = VariableArray<VariableArray<VariableArray<VariableArray<VariableArray<Vector>, Vector[][]>, Vector[][][]>, Vector[][][][]>, Vector[][][][][]>;
	 
	
	public static class InferNetAux
	{
		#region Aux
		private static readonly System.Random rand = new System.Random();
		
		public static int LengthOf<TEnum>()
		{
			return Enum.GetValues(typeof(TEnum)).Length;
		}
		#endregion
		
		#region Random generation	
		public static Vector[][][][] GenerateRandomProbs(int r1Len, int r2Len, int r3Len, int r4Len, int vectLen)
		{
			var result = new Vector[r1Len][][][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len][][];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = new Vector[r3Len][];
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						result[r1Idx][r2Idx][r3Idx] = new Vector[r4Len];
						for(int r4Idx = 0; r4Idx < r4Len; r4Idx++)
						{
							result[r1Idx][r2Idx][r3Idx][r4Idx] = Vector.FromArray(GenerateRandomDistribution(vectLen, 2));
						}
					}
				}
			}
			return result;
		}
		
		public static Vector[][][] GenerateRandomProbs(int r1Len, int r2Len, int r3Len, int vectLen)
		{
			var result = new Vector[r1Len][][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len][];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = new Vector[r3Len];
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						result[r1Idx][r2Idx][r3Idx] = Vector.FromArray(GenerateRandomDistribution(vectLen, 2));
					}
				}
			}
			return result;
		}
		
		public static Vector[][] GenerateRandomProbs(int r1Len, int r2Len, int vectLen)
		{
			var result = new Vector[r1Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = Vector.FromArray(GenerateRandomDistribution(vectLen, 2));
				}
			}
			return result;
		}

		public static Vector[] GenerateRandomProbs(int r1Len, int vectLen)
		{
			var result = new Vector[r1Len];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = Vector.FromArray(GenerateRandomDistribution(vectLen, 2));
			}
			return result;
		}

		
		public static double[,,,][] GenerateRandomCPTDouble(int r1Len, int r2Len, int r3Len, int r4Len, int vectLen)
		{
			var result = new double[r1Len, r2Len, r3Len, r4Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						for(int r4Idx = 0; r4Idx < r4Len; r4Idx++)
						{
							result[r1Idx, r2Idx, r3Idx, r4Idx] = GenerateRandomDistribution(vectLen, 2);
						}
					}
				}
			}
			return result;
		}
		
		public static double[,,][] GenerateRandomCPTDouble(int r1Len, int r2Len, int r3Len, int vectLen)
		{
			var result = new double[r1Len, r2Len, r3Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						result[r1Idx, r2Idx, r3Idx] = GenerateRandomDistribution(vectLen, 2);
					}
				}
			}
			return result;
		}
		
		public static double[,][] GenerateRandomCPTDouble(int r1Len, int r2Len, int vectLen)
		{
			var result = new double[r1Len, r2Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx, r2Idx] = GenerateRandomDistribution(vectLen, 2);
				}
			}
			return result;
		}
		
		public static double[][] GenerateRandomCPTDouble(int r1Len, int vectLen)
		{
			var result = new double[r1Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = GenerateRandomDistribution(vectLen, 2);
			}
			return result;
		}

		public static double[] GenerateRandomDistribution(int length, int decimalPlaces)
		{
			if(length < 1)
			{
				throw new ArgumentOutOfRangeException();
			}
			
			var result = new double[length];
			for(int i = 0; i < result.Length; i++)
			{
				result[i] = rand.Next(0,100);
			}
			
			var sum = result.Aggregate((a, b) => a +b );
			result = result.Select( prob => Math.Round(prob/sum, decimalPlaces)).ToArray();
			
			var sumMinusLast = result.Take(result.Length-1).Aggregate((a,b) => a + b);
			result[result.Length-1] = 1 - sumMinusLast;
			
			//Check if sum of probabilities equals 1
			sum = result.Aggregate((a, b) => a +b );
			if(sum != 1)
			{
				throw new Exception("Does not sum to 1");
			}

			return result;
		}		
			
		#endregion
		
		#region conversion to jagged arrays
		
		public static Vector[][][][] ToJaggedArray(double[,,,][] probabilities)
		{
			var r1Len = probabilities.GetLength(0);
			var r2Len = probabilities.GetLength(1);
			var r3Len = probabilities.GetLength(2);
			var r4Len = probabilities.GetLength(3);
			
			var result = new Vector[r1Len][][][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len][][];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = new Vector[r3Len][];
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						result[r1Idx][r2Idx][r3Idx] = new Vector[r4Len];
						for(int r4Idx = 0; r4Idx < r4Len; r4Idx++)
						{
							result[r1Idx][r2Idx][r3Idx][r4Idx] = Vector.FromArray(probabilities[r1Idx, r2Idx, r3Idx, r4Idx]);
						}
					}
				}
			}
			return result;
		}
		
		public static Vector[][][] ToJaggedArray(double[,,][] probabilities)
		{
			var r1Len = probabilities.GetLength(0);
			var r2Len = probabilities.GetLength(1);
			var r3Len = probabilities.GetLength(2);
			
			var result = new Vector[r1Len][][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len][];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = new Vector[r3Len];
					for(int r3Idx = 0; r3Idx < r3Len; r3Idx++)
					{
						result[r1Idx][r2Idx][r3Idx] = Vector.FromArray(probabilities[r1Idx, r2Idx, r3Idx]);
					}
				}
			}
			return result;
		}
		
		public static Vector[][] ToJaggedArray(double[,][] probabilities)
		{
			var r1Len = probabilities.GetLength(0);
			var r2Len = probabilities.GetLength(1);
			
			var result = new Vector[r1Len][];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = new Vector[r2Len];
				for(int r2Idx = 0; r2Idx < r2Len; r2Idx++)
				{
					result[r1Idx][r2Idx] = Vector.FromArray(probabilities[r1Idx, r2Idx]);
				}
			}
			return result;
		}
		
		public static Vector[] ToJaggedArray(double[][] probabilities)
		{
			var r1Len = probabilities.GetLength(0);
			
			var result = new Vector[r1Len];			
			for(int r1Idx = 0; r1Idx < r1Len; r1Idx++)
			{
				result[r1Idx] = Vector.FromArray(probabilities[r1Idx]);
			}
			return result;
		}
		#endregion
		
				
		#region Conditional Probability Tables constructors				
		public static VarVectArr4 GetCPT(Range r1, Range r2, Range r3, Range r4,
										 double[,,,][] probabilities)
		{
			var a = Variable.Array<Vector>(r4);
			var b = Variable.Array<VarVectArr, Vector[][]>(a, r3);
			var c = Variable.Array<VarVectArr2, Vector[][][]>(b, r2);
			var cpt = Variable.Array<VarVectArr3, Vector[][][][]>(c, r1);
			
			cpt.ObservedValue =  ToJaggedArray(probabilities);
			
			return cpt;
		}
		
		public static VarVectArr3 GetCPT(Range r1, Range r2, Range r3,
										 double[,,][] probabilities)
		{
			var a = Variable.Array<Vector>(r3);
			var b = Variable.Array<VarVectArr, Vector[][]>(a, r2);
			var cpt = Variable.Array<VarVectArr2, Vector[][][]>(b, r1);
			
			cpt.ObservedValue =  ToJaggedArray(probabilities);
			
			return cpt;
		}
		
		public static VarVectArr2 GetCPT(Range r1, Range r2,
										 double[,][] probabilities)
		{
			var a = Variable.Array<Vector>(r2);
			var cpt = Variable.Array<VarVectArr, Vector[][]>(a, r1);
			
			cpt.ObservedValue =  ToJaggedArray(probabilities);
			
			return cpt;
		}
		
		public static VarVectArr GetCPT(Range r1,
										 double[][] probabilities)
		{
			var cpt = Variable.Array<Vector>(r1);
			
			cpt.ObservedValue =  ToJaggedArray(probabilities);
			
			return cpt;
		}
		#endregion
		
		#region Discrete Variable dependent on parents contructors
		public static Variable<int> VariableDiscrete(Range range, Variable<int> parent1, VarVectArr cpt)
		{
		     // data range
		     var child = Variable.New<int>();
		     using (Variable.Switch(parent1))
		     child.SetTo(Variable.Discrete(range, cpt[parent1] ));
		     return child;
		}

		
		public static Variable<int> VariableDiscrete(Range range, Variable<int> parent1, Variable<int> parent2,
									    			 VarVectArr2 cpt)
		{
		     // data range
		     var child = Variable.New<int>();
		     using (Variable.Switch(parent1))
		     using (Variable.Switch(parent2))
		     child.SetTo(Variable.Discrete(range, cpt[parent1][parent2] ));
		     return child;
		}

		
		public static Variable<int> VariableDiscrete(Range range, Variable<int> parent1, Variable<int> parent2,
									     			 Variable<int> parent3, VarVectArr3 cpt)
		 {
		     // data range
		     var child = Variable.New<int>();
		     using (Variable.Switch(parent1))
		     using (Variable.Switch(parent2))
		     using (Variable.Switch(parent3))
		     child.SetTo(Variable.Discrete(range, cpt[parent1][parent2][parent3] ));
		     return child;
		 }

		
		public static Variable<int> VariableDiscrete(Range range, Variable<int> parent1, Variable<int> parent2,
									     			 Variable<int> parent3, Variable<int> parent4,
									     			 VarVectArr4 cpt)
		{
			var child = Variable.New<int>();
			using (Variable.Switch(parent1))
			{
				using (Variable.Switch(parent2))
				{
					using (Variable.Switch(parent3))
					{
						using (Variable.Switch(parent4))
						{
							child.SetTo(Variable.Discrete(range, cpt[parent1][parent2][parent3][parent4] ));
						}
					}
				}
			} 
		    return child;
		 }
	
		
		#endregion
		
		
		
	}
}

