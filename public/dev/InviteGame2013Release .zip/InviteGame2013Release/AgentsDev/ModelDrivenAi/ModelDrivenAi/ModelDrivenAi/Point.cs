using System;

namespace ModelDrivenAi
{
	/**
	* Point Object to be used by our Clustering Algorithm this will actually represent the agents 
	* in the clustering algorithm
	* */
	public class Point {
		
		private static int VALUE_THRESHOLD = 100;
		
		// Coordinate List as there can be more than one coordinate.
		double[] dimension_points;
		
		// Point ID or more specifically the agent ID
		public String ID;
		
		/**
		 * Constructor Method for the Point Class.
		 * */
		public Point (double[] values, String ID)
		{
			this.dimension_points = values;
			this.ID = ID;
		}
		
		/**
		 * Constructor method that only needs the ID of the cluster.
		 * */
		public Point (int dimensions, String ID)
		{
			Random rand = new Random ();
			this.ID = ID;
			this.dimension_points = new double[dimensions];
			for (int i = 0; i < this.dimension_points.Length; i++) {
				this.dimension_points [i] = rand.Next (0, VALUE_THRESHOLD + 1);
			}
		}
		
		/**
		 * Sets the Coordinates of this Point. Mostly used with the Centroid attribute.
		 * */
		public void setPoint (double[] coodinates)
		{
			this.dimension_points = coodinates;
		}
		
		
		/**
		 * Returns the List of Coordinates of this Point.
		 * */
		public double[] getPoints ()
		{
			return dimension_points;
		}
		
		/**
		 * Returns the ID of this Point.
		 * */
		public String getID ()
		{
			return ID;
		}
		
		/**
		 * Static Method that calculates the distance between two Points
		 * */
		public static double FindDistance (Point pt1, Point pt2)
		{
			double[] coordinates = new double[pt1.getPoints ().Length];
			double sum_array = 0;
			for (int i = 0; i < pt1.getPoints().Length; i++) {
				coordinates [i] = pt1.getPoints () [i] - pt2.getPoints () [i];
				coordinates [i] = Math.Pow (coordinates [i], 2.0);
			}
			
			foreach (double num in coordinates) {
				sum_array += num;
			}
			return Math.Sqrt(sum_array);
		}
		
		/**
		 * Returns the string representation of this Point.
		 * */
		public override string ToString()
		{
			string str = "Point: ID " + "Points:";
			foreach (double coord in dimension_points) {
				str += " ," + coord;
			}
			str += ".";
			return str;
		}
		
		/**
		 * Verifies if an object obj is equal to this one.
		 * */
		public override bool Equals(object obj)
		{
			if (obj is Point)
			{
				Point point = (Point)obj;
				if(dimension_points.Length == point.getPoints().Length)
				{
					for(int i = 0; i < dimension_points.Length; i++)
					{
						if(dimension_points[i] != point.getPoints()[i])
						{
							return (false);
						}
					}
					return (true);
				}
			}
			return (false);
		}
	}
}

