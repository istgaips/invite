using System;

namespace ModelDrivenAi
{
	public class Color : Characteristic
	{
		/**
		 * Temporary code for this class. Will add more if needed
		 **/
		private Color (String name): base(name)
		{
			// Do Nothing as of yet.
		}
		
		/**
		 * Factory Method of this object. Will need to later define the color pallette of this object.
		 * Need a Static Method where I can define the colors of this caracteristic */
		public static Color ColorFactory (String name)
		{
			// This is temporary Factory Code!
			if (name.Equals ("Blue") || name.Equals ("blue") ) {
				Color blue_color = new Color ("Blue");
				blue_color.setValue (100.0);
				return blue_color;
			} else {
				Color red_color = new Color ("Red");
				red_color.setValue (0.0);
				return red_color;
			}
		}
	}
}
