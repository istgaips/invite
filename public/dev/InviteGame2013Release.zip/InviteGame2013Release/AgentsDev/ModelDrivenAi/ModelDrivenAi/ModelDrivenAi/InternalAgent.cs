using System;
using System.Collections.Generic;

namespace ModelDrivenAi
{
	/**
	 * This class has the objective of representing the other player agents with each their own name and characteristics.
	 * */
	
	public class InternalAgent
	{
		List<Characteristic> agent_characteristics;
		String agent_name;
		
		public InternalAgent (String agent_name)
		{
			this.agent_name = agent_name;
			agent_characteristics = new List<Characteristic>();
		}
		
		public void addCharacteristic (Characteristic new_characteristic)
		{
			agent_characteristics.Add(new_characteristic);
		}
		
		public void removeCharacteristic (Characteristic remove_characteristic)
		{
			agent_characteristics.Remove (remove_characteristic);
		}
		
		public String getName ()
		{
			return agent_name;
		}
		
		public List<Characteristic> getCharacteristics ()
		{
			return agent_characteristics;
		}
		
	}
}

