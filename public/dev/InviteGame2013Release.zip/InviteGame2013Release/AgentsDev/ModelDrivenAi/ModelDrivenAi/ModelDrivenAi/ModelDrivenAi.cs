using System;
using System.Collections.Generic;
using INVITE;
using ION.Agents;
using System.Threading;
using ModelDrivenAi;

namespace INVITE.Agents
{
	public class ModelDrivenAi : Player
	{
		private uint minDelay = 0;
		private uint maxDelay = 10;
		private bool isMoving;

		// Identity Agent Constants
		private List<Player> player_list = new List<Player>();
		private int num_players;
		private int num_teams;

		private KMeansCluster my_kmean;

		private double current_day;
		private double collected_wood_last_round;
		private double number_of_team_members;


		//double other_survivor_bonus = Game.Instance.WoodRequiredForRaftCompletion * Game.Instance.GoldPerWoodUnit;
		// Simplify
		private double survive_bonus = 20;

		// Value of maximum wood obtained per day if all members cooperate.
		public double allCooperateValue; 
		
		// Value of wood obtained if all team members cooperate but me.
		public double myDefectValue;
		
		// Value of wood obtained if I cooperate but my team members do not.
		public double iCooperateValue;



		public ModelDrivenAi(string myid, string name, string mytype, ITeam team, uint playerTimePerDay)
			: base (myid, name, mytype, team, playerTimePerDay)
		{
			this.isMoving = false;
			this.Mover.Started += this.OnMoveStarted;
			this.Mover.Stopped += this.OnMoveStopped;
			//The following two callbacks serve the same purpose, but sometimes one doesn't work, we I put both in there
			//to have a better guarantee my agent will indeed be warned that he has collected the resourcs.
			this.TimeLeftToday.ValueChanged += this.HoursValueChanged;	
			this.MiniGamePlayer.Stopped += this.OnMiniGameStopped;

			this.my_kmean = null;
			current_day = 1;
			collected_wood_last_round = 0;
			number_of_team_members = 0;


		}

		public void OnMoveStarted(ION.Agents.IStartedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) {
			this.isMoving = true;
			this.Mover.Pause();
			//Console.WriteLine("Agente " + this.Name + " started moving_aknowledgement");
		}
		
		public void OnMoveStopped(ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) 
		{
			//Console.WriteLine("Agente " + this.Name + " stopped moving_aknowledgement");
			this.isMoving = false;
			this.DecideAction();
		}

		/**
		 * Decides the Action the Agent is going to take.
		 * */
		private void DecideAction()
		{
			if(this.TimeLeftToday.Value > 0) // Agent has time to gather resources
			{
				if(this.Locale.Value is IResourceSite) // Agent at resource site. Gather resources
				{
					this.PlayRandomMiniGame();
				}
				else // Move to resource site
				{
					//Console.WriteLine("Agente " + this.Name + " moving to resourceSite");
					this.Mover.Start(new MoveTo(InviteRandom.Instance.RandomResourceSite));
				} 
			}
			else if (this.Locale.Value != this.Team.CampSite) // No more time left and not at camp site. Go to camp site 
			{
				//Console.WriteLine("Agente " + this.Name + " moving to campSite");
				this.Mover.Start(new MoveTo(this.Team.CampSite));
			}
		}

		protected void OnMiniGameStopped (IStoppedEvent<IMultipleStepEffector<MiniGame>> evt) {
			Console.WriteLine("Agente " + this.Name + " played a minigame");
			if (!this.isMoving)
			{
				this.DecideAction();
			}			
		}

		public void PlayRandomMiniGame ()
		{
			///THIS IS OLD CODE!! FROM RANDOM AGENT
//			uint timeLeftToday = this.TimeLeftToday.Value;
//			
//			uint wood = InviteRandom.Instance.RandomBetween(0, timeLeftToday);
//			uint gold = timeLeftToday - wood;
			uint delay = InviteRandom.Instance.RandomBetween(this.minDelay, this.maxDelay);
			//Console.WriteLine("Agente " + this.Name + " playing with wood " + wood + " and gold " + gold + " and delay " + delay);


			// THIS IS NEW CODE FROM IDENTITY AGENT
			if(my_kmean == null)
				startupKMean();

			double salience_value = SalienceCalc.calcSalience (this.my_kmean);
			double rational_value = calcRationality();

			double final_value = (salience_value + rational_value) / 2;

			
			// The Calculation of the Fit Value is temporary
			uint wood = (uint)Math.Round(final_value*10, 0, MidpointRounding.AwayFromZero);
			uint gold = Game.Instance.GameConfiguration.PlayerTimePerDay - wood;

			//NO THRESHOLD FUNCTION
//			System.IO.StreamWriter file = new System.IO.StreamWriter("IdentityAgentDebuggerCollection" + base.Name + ".txt");
//			file.WriteLine("Wood Collected = " + wood + "\r\nGold Collected = " + gold);
//			file.Close();

			this.MiniGamePlayer.Start(new MiniGame(wood, gold, delay));
			current_day++;
			collected_wood_last_round = wood;
		}

		public void HoursValueChanged (ION.Agents.IValueChangedEvent<uint> evt)
		{
			//Console.WriteLine("Agente " + this.Name + " had his hours changed to " + evt.Property.Value);
			if (!this.isMoving)
			{
				this.DecideAction();
			}
		}

		public String getAllPlayers (List<Player> player_list)
		{
			string str = "";
			foreach (Player player in player_list) {
				str += player.Name + ", ";
			}
			return str;
		}


		public void startupKMean()
		{

			/// Identity Function Kickstart
			//System.IO.StreamWriter file = new System.IO.StreamWriter("IdentityAgentDebugger" + base.Name + ".txt");
			//My code starts here defining the variable.
			// The Existing Players of the Game
			String str = "";

			List<String> used_colors = new List<String>();

			foreach (Player player in Game.Instance.Players) {
				player_list.Add (player);
				str += player.Name + ", Team : " + player.Team.Name + ", Color : " + player.UniformColor.Value + "\r\n";
				if(!used_colors.Contains(player.UniformColor.Value.ToString()))
					used_colors.Add(player.UniformColor.Value.ToString());
				if(base.Team.Name.Equals(player.Team.Name))
					number_of_team_members++;
			}
			
			
			// The Number of Players
			num_players = player_list.Count;
			
			// Number of Teams
			num_teams = Game.Instance.GameConfiguration.Teams.Count;
			
//			file.WriteLine("Constants Attributed Print them:" +
//			               "Player List is : " + str +
//			               "Number Players = " + num_players +
//			               "Number Teams = " + num_teams +
//			               "Number of Players per Team = " + number_of_team_members);


			

			//CONFIGURING THE KMEANS ALGORITHM
			// The Agent List used in the clustering algorithm.
			InternalAgent[] agent_list = new InternalAgent[ num_players ];
			
			int counter = 0;
			foreach (Player player in player_list) {
				agent_list[counter] = new InternalAgent(player.playerID);
				agent_list[counter].addCharacteristic(CSite.CampSiteFactory(player.Team.Name));
				//agent_list[counter].addCharacteristic(Color.ColorFactory( player.UniformColor.Value.ToString()) );
				setColorCaracteristics(agent_list[counter], player, used_colors);

				// Set Characteristic Number
				Characteristic.setCharacteristicNumber(agent_list[counter].getCharacteristics().Count);

				counter++;
			}
			this.my_kmean = new KMeansCluster(agent_list, base.playerID);

			//file.WriteLine("KMeans is " + this.my_kmean.ToString());


			/// Racional Function Kickstart
			
			allCooperateValue = number_of_team_members * Game.Instance.GameConfiguration.PlayerTimePerDay;		
			myDefectValue = (number_of_team_members - 1) * Game.Instance.GameConfiguration.PlayerTimePerDay;	
			iCooperateValue = Game.Instance.GameConfiguration.PlayerTimePerDay;


			//file.Close();
		}


		public void setColorCaracteristics (InternalAgent agent, Player player, List<String> used_colors)
		{
			foreach (String color in used_colors) {
				if(color.Equals(player.UniformColor.Value.ToString())){
					Color my_color = Color.ColorFactory(player.UniformColor.Value.ToString());
					my_color.setValue(100);
					agent.addCharacteristic(my_color);
				} else {
					Color other_color = Color.ColorFactory(color.ToString());
					other_color.setValue(0);
					agent.addCharacteristic(other_color);
				}
			}
		}

		////////////////////////// FUNCTIONS FOR OUR RATIONAL MODEL //////////////////////////////////
		
		
		// Calculates the Fi to be used in the rational model.
		public double calcFi ()
		{
			double collected_wood = 0;
			if (current_day > 1) {
				collected_wood = collected_wood_last_round;
			}
			
			double value_2 = (Game.Instance.GameConfiguration.PlayerTimePerDay * current_day);
			double Fi_result = collected_wood / value_2;
			
			
			return Fi_result;
		}
		
		// Calculates the value if everyone cooperates.
		// (F_i + (30/MaxM_i))(B+otherGold)
		public double calcAllCooperate ()
		{
			double F_i = calcFi();
			
			// Maximum wood that was possible to collect at that particular time.
			double maxWood_i = Game.Instance.GameConfiguration.PlayerTimePerDay * current_day;
			double totalTeamGold = this.Team.GoldCollected;
			double divider = (survive_bonus + (totalTeamGold / number_of_team_members) );

			// Do the calculation
			return ( (F_i + (allCooperateValue / maxWood_i)) * divider );
		}
		
		// Calculates the value if I cooperate but everyone else defects.
		// (F_i + (10/MaxM_i))(B+otherGold + 10)
		public double calcICooperate ()
		{
			double F_i = calcFi();
			
			// Maximum wood that was possible to collect at that particular time.
			double maxWood_i = Game.Instance.GameConfiguration.PlayerTimePerDay * current_day;
			double totalTeamGold = this.Team.GoldCollected;
			double divider = (survive_bonus + (totalTeamGold / number_of_team_members)) + Game.Instance.GameConfiguration.PlayerTimePerDay;
			
			
			// Do the calculation; Game.MAX_CARRYING = maximum gold I can carry.
			return ( (F_i + (iCooperateValue / maxWood_i)) * divider );
		}
		
		
		// Calculates the value if everyone cooperates but myself.
		// (F_i + (20/MaxM_i))(B+otherGold)
		public double calcIDefect ()
		{
			double F_i = calcFi();
			
			// Maximum wood that was possible to collect at that particular time.
			double maxWood_i = Game.Instance.GameConfiguration.PlayerTimePerDay * current_day;
			double totalTeamGold = this.Team.GoldCollected;

			double divider = ( survive_bonus + (totalTeamGold / number_of_team_members) );
			
			// Do the calculation
			return ( (F_i + (myDefectValue / maxWood_i) ) * divider);
		}
		
		// Calculates the value if everyone defects.
		// (F_i)(B+otherGold+10); Game.MAX_CARRYING = maximum gold I can carry.
		public double allDefect ()
		{
			double F_i = calcFi();
			
			// Maximum wood that was possible to collect at that particular time.
			double maxWood_i = Game.Instance.GameConfiguration.PlayerTimePerDay * current_day;
			double totalTeamGold = this.Team.GoldCollected;
			double divider = (survive_bonus + (totalTeamGold / number_of_team_members) + Game.Instance.GameConfiguration.PlayerTimePerDay);
			
			// Do the calculation
			return ( F_i * divider);
		}
		
		// Calculates the rational probability in which the agent is willing to cooperate.
		public double calcRationality ()
		{
			double L_1 = calcAllCooperate();
			double L_2 = calcIDefect();
			double R_1 = calcICooperate();
			double R_2 = allDefect();
			double p = ( (R_2 - L_2) / (L_1 - R_1 - L_2 + R_2)) / Game.Instance.GameConfiguration.PlayerTimePerDay;
			
			//			Console.WriteLine(this.GetPlayerName() + " Information : F_i = " + calcFi() + 
			//			                  "\r\nL_1 = " + L_1 +
			//			                  "\r\nL_2 = " + L_2 +
			//			                  "\r\nR_1 = " + R_1 +
			//			                  "\r\nR_2 = " + R_2 +
			//			                  "\r\nP = " + p);		
			
			return p; 
		}
		
	}
}

