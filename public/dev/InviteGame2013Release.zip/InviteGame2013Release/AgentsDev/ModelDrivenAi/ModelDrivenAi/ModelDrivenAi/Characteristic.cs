using System;

namespace ModelDrivenAi
{
	/**
	 * This is the archetype of the characteristic. We will then define the sub-levels of the characteristics.
	 */ 
	public class Characteristic
	{
		double value;
		String name;
		
		public static int NUMBER_OF_CHARACTERISTICS = 2;

		/**
		 * Changes the number of maximum Characteristics per Agent. Default Value is = 2.
		 * **/
		public static void setCharacteristicNumber (int num)
		{
			NUMBER_OF_CHARACTERISTICS = num;
		}
		
		public Characteristic (String name)
		{
			this.name = name;
		}
		
		public void setValue (double value)
		{
			this.value = value;
		}
		
		public double getValue()
		{
			return value;
		}
		
		public String getName ()
		{
			return name;
		}
		
		public Boolean isSameType (Characteristic comparer)
		{
			if (this.name.Equals (comparer.name)) {
				return true;
			} else {
				return false;
			}
		}
	}
}

