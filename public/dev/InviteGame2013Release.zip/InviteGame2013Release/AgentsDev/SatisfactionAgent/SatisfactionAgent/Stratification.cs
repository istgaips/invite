using System;

namespace INVITE.Agents
{
	public class Stratification
	{
		public Stratification ()
		{
		}
	}
}

