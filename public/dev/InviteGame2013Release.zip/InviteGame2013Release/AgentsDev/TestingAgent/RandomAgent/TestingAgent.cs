using System;
using INVITE;
using ION.Agents;
using ION.Meta;
using System.Linq;
using System.Threading;
using System.Collections.Generic;

namespace INVITE.Agents
{
	public class TestingAgent : Player
	{		
		private uint minDelay = 0;
		private uint maxDelay = 1;
		private bool isMoving;
		private LinkedList<EventHandlingProxy> eventsToHandle; //ION level feedback events that we are listening to.
	
		//private static readonly Random random = new Random();
		
		public TestingAgent(string name, ITeam team, uint playerTimePerDay)
			: base (name, team, playerTimePerDay)
		{
			this.isMoving = false;
			this.eventsToHandle = new LinkedList<EventHandlingProxy> ();
			EventHandlingProxy evt;
			
			evt = new EventHandlingProxy (this.Mover);
			evt.Add<ION.Agents.IStartedEvent<IMultipleStepEffector<INVITE.MoveTo>>> (this.OnMoveStarted);	
			evt.Add<ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MoveTo>>> (this.OnMoveStopped);
			eventsToHandle.AddLast(evt);
			//The following two callbacks serve the same purpose, but sometimes one doesn't work, we I put both in there
			//to have a better guarantee my agent will indeed be warned that he has collected the resourcs.
			evt = new EventHandlingProxy ((Element)this.TimeLeftToday);
			evt.Add<ION.Agents.IValueChangedEvent<uint>> (this.HoursValueChanged);
			eventsToHandle.AddLast (evt);
			
			evt = new EventHandlingProxy ((Element)this.MiniGamePlayer);
			evt.Add<ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MiniGame>>> (this.OnMiniGameStopped);
			eventsToHandle.AddLast (evt);
	
		}
		
		public void checkEvents(){
			foreach(EventHandlingProxy evt in eventsToHandle){
				evt.HandleEvents();	
			}
		}
		
		
		public void OnMoveStarted(ION.Agents.IStartedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) {
			this.isMoving = true;
			Console.WriteLine("Agente " + this.Name + " started moving_aknowledgement");
		}
		
		public void OnMoveStopped(ION.Agents.IStoppedEvent<IMultipleStepEffector<INVITE.MoveTo>> evt) 
		{
			Console.WriteLine("Agente " + this.Name + " stopped moving_aknowledgement");
			this.isMoving = false;
			this.DecideAction();
		}
		
		protected void OnMiniGameStopped (IStoppedEvent<IMultipleStepEffector<MiniGame>> evt) {
			Console.WriteLine("Agente " + this.Name + " played a minigame");
			if (!this.isMoving)
			{
				this.DecideAction();
			}			
		}
		
		public void HoursValueChanged (ION.Agents.IValueChangedEvent<uint> evt)
		{
			Console.WriteLine("Agente " + this.Name + " had his hours changed to " + evt.Property.Value);
			if (!this.isMoving)
			{
				this.DecideAction();
			}
		}


		private void DecideAction()
		{
			if(this.TimeLeftToday.Value > 0) // Agent has time to gather resources
			{
				if(this.Locale.Value is IResourceSite) // Agent at resource site. Gather resources
				{
					this.PlayRandomMiniGame();
				}
				else // Move to resource site
				{
					Console.WriteLine("Agente " + this.Name + " moving to resourceSite");
					this.Mover.Start(new MoveTo(InviteRandom.Instance.RandomResourceSite));
				} 
			}
			else if (this.Locale.Value != this.Team.CampSite) // No more time left and not at camp site. Go to camp site 
			{
				Console.WriteLine("Agente " + this.Name + " moving to campSite");
				this.Mover.Start(new MoveTo(this.Team.CampSite));
			}
		}
		
		public void PlayRandomMiniGame ()
		{
			uint timeLeftToday = this.TimeLeftToday.Value;
			
			uint wood = InviteRandom.Instance.RandomBetween(0, timeLeftToday);
			uint gold = timeLeftToday - wood;
			uint delay = InviteRandom.Instance.RandomBetween(this.minDelay, this.maxDelay);
			Console.WriteLine("Agente " + this.Name + " playing with wood " + wood + " and gold " + gold + " and delay " + delay);
			this.MiniGamePlayer.Start(new MiniGame(wood, gold, delay));
		}
	}
}

