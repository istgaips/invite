using System;
using UnityEngine;
using System.Collections.Generic;
using System.Threading;

public class HexMiniGame : IMiniGame
{
	public HexMiniGame (uint WoodPerTimeUnit, uint GoldPerTimeUnit)
		: base (WoodPerTimeUnit,GoldPerTimeUnit)
	{
		Debug.Log("Initializing HexMiniGame to get Hex stuff harhar: " + this.GetType().Namespace);
		string path = Application.dataPath;
		if(path.Contains("Invite_Data")){
			path = path.Replace("Invite_Data","MiniGames");
		}

		WWW wwww = new WWW("file://"+ path + "/HexBoardAssetBundle.unity3d");
		//while(!wwww.isDone);
		AssetBundle assets = wwww.assetBundle;
		GameObject hexboard = (GameObject) GameObject.Instantiate(wwww.assetBundle.Load("HexBoardPrefab") as GameObject);
		Component[] components = hexboard.GetComponents<Component>();
		for(int i=0; i< components.Length; i++ ){
			if(components[i] == null){
				Debug.Log("Destroying this thing.");
				rsctracker = hexboard.AddComponent<ResourceTracker>();
				components[i] = rsctracker;
			}
		}
		rsctracker.enabled=false;
		rsctracker.gameObject.renderer.enabled=false;
		rsctracker.transform.parent = Camera.main.transform;
		rsctracker.transform.localScale = new Vector3(0.6f,1,1.2f);
		rsctracker.transform.rotation = new Quaternion(0.49f,0.49f,-0.5f,-0.5f);
		rsctracker.transform.localRotation = new Quaternion(0.49f,0.49f,-0.5f,-0.5f);
		rsctracker.transform.position = new Vector3(-0.09f,0,-30);
		rsctracker.transform.localPosition = new Vector3(-0.09f,0,-30);
		
		for(int i = 0; i<rsctracker.transform.childCount;i++){
			GameObject comp = rsctracker.transform.GetChild(i).gameObject;
			if(comp.name.Contains("light")){
				comp.GetComponent<Light>().enabled=false;	
				lightindex = i;
			}
			string compname = comp.name;
			Debug.Log("Initializing script for " + compname);
			if(compname.Contains("Mark")){
				Marker marker = comp.AddComponent<Marker>();	
				markcount++;
			}
			if(compname.Contains("Sphere")){
				ResourceInteraction rscinter = comp.AddComponent<ResourceInteraction>();	
				rscinter.resTracker = rsctracker;
				rscinter.gameObject.layer= LayerMask.NameToLayer("Default");
				compname = compname.Replace("Sphere","");
				string []split = compname.Split('-');
				rscinter.howManyGold = Int32.Parse(split[0]);
				rscinter.howManyWood = Int32.Parse(split[1]);
				Debug.Log("RscIntrc initialized with gold and wood " + rscinter.howManyGold + " and " + rscinter.howManyWood);
			}
		}
		Debug.Log("Loading the scene objects " + rsctracker.name);
		
		//rsctracker = (ResourceTracker) GameObject.FindGameObjectWithTag("HexIsland").GetComponent<ResourceTracker>();
		//Camera.main.gameObject.AddComponent<> ();
	//	rsctracker.gameObject.renderer.enabled=false;
	}

	private int GUIWidth = 500; 						// Defines the GUI background width
	private int GUIHeight = 300; 						// Defines the GUI background height
	private int GUIPosX;// = (Screen.width-GUIWidth)/2; 	// Defines the GUI position on the X axis
	private int GUIPosY; //= (Screen.height-GUIHeight)/2; 	// Defines the GUI position on the Y axis
	private int buttonWidth = 200;
	private int buttonHeight = 80;
	private int textFieldWidth = 32;
	private int textFieldHeight = 32;
	private ResourceTracker rsctracker;
	private int markcount = 0;
	private string ACTIONMESSAGE = "Time Actions: ";
	private string GOLDMESSAGE = "Gold: ";
	private string WOODMESSAGE = "Wood: ";
	private int lightindex; 
		
	private void Init(){
		hoursSpendWood = 0;
		hoursSpendGold = 0;
		rsctracker.goldUnits = 0;
		rsctracker.woodUnits = 0;
		rsctracker.resetActions();
		rsctracker.transform.position = new Vector3(-0.09f,0,8);
		rsctracker.transform.localPosition = new Vector3(-0.09f,0,8);
		GUIPosX = (Screen.width-GUIWidth)/2;
		GUIPosY = (Screen.height-GUIHeight)/2;;
		rsctracker.gameObject.renderer.enabled=true;
		rsctracker.enabled=true;
	}		
	
	private void Exit(){
		rsctracker.gameObject.renderer.enabled=false;
		rsctracker.transform.position = new Vector3(rsctracker.transform.position.x,rsctracker.transform.position.y,-30);
		rsctracker.transform.localPosition = new Vector3(rsctracker.transform.position.x,rsctracker.transform.position.y,-30);
		for(int i = 0; i<rsctracker.transform.childCount;i++){
			GameObject comp = rsctracker.transform.GetChild(i).gameObject;
			string compname = comp.name;
			if(compname.Contains("Sphere")){
				if(comp.GetComponent<ResourceInteraction>().marker!=null){
					comp.GetComponent<ResourceInteraction>().marker.Deactivate();
					comp.GetComponent<ResourceInteraction>().marker = null;	
				}
			}
		}
		hoursSpendWood = (uint) rsctracker.woodUnits;
		hoursSpendGold = (uint) rsctracker.goldUnits;
		rsctracker.gameObject.renderer.enabled=false;
		rsctracker.enabled=false;
		rsctracker.transform.GetChild(lightindex).gameObject.GetComponent<Light>().enabled=false;
	}

	override public void PlayMinigame(uint hoursleft){
		Debug.Log("Playing Hex Minigame");
		rsctracker.totalActions = (int) hoursleft/3;
		if(rsctracker.totalActions>markcount){
			for(int i = markcount; i<rsctracker.totalActions; i++){
				Debug.Log("new marker");
				GameObject oldmarker = (GameObject) GameObject.Find("Mark"+i);
				GameObject newmarker = GameObject.Instantiate((UnityEngine.Object)oldmarker,oldmarker.transform.position,oldmarker.transform.rotation) as GameObject;
				newmarker.transform.parent = rsctracker.transform;
				newmarker.name = "Mark"+(i+1);
				newmarker.transform.localScale = GameObject.Find("Mark"+i).transform.localScale;
			}
			markcount = rsctracker.totalActions;
		}
		this.hoursLeft=hoursleft;
		Init ();
		rsctracker.enabled=true;
		rsctracker.transform.GetChild(lightindex).gameObject.GetComponent<Light>().enabled=true;	
	}	
	
	override public void Draw ()
	{
		uint collectedGameWood = woodCollectedPerHour * (uint)rsctracker.woodUnits;
		uint collectedGameGold = goldCollectedPerHour * (uint)rsctracker.goldUnits;
		
		GUI.Label (new Rect (Screen.width/1.42f, 20, Screen.width-(Screen.width/1.39f), GUIHeight/3*2), GUITextLabels.MiniGameText7 + ":\n " + collectedGameWood + " " + GUITextLabels.MiniGameText4 + " " + GUITextLabels.MiniGameText8 + " " + collectedGameGold + " " + GUITextLabels.MiniGameText5, GUIStyles.rightTextStyle);
		GUI.Label (new Rect (0, 20, 500, 100), ACTIONMESSAGE + rsctracker.getActionsLeft(), GUIStyles.leftBoldedTextStyle);
		GUI.Label (new Rect (0, 40, 500, 100), WOODMESSAGE + rsctracker.woodUnits,GUIStyles.leftBoldedTextStyle);
		GUI.Label (new Rect (0, 60, 500, 100), GOLDMESSAGE + rsctracker.goldUnits,GUIStyles.leftBoldedTextStyle);
		
		
		if (GUI.Button (new Rect (0,Screen.height-buttonHeight, buttonWidth, buttonHeight), GUITextLabels.MiniGameConfirmText6))
		{
			this.Exit();
			this.clickCancel();
		}
		// Draws the  button
		if (GUI.Button (new Rect (Screen.width - buttonWidth, Screen.height-buttonHeight, buttonWidth, buttonHeight), "OK"))
		{
			this.Exit();
			this.clickOK();
		}
	}
}